#!/bin/bash
chmod +x "$(dirname "$0")"/*.command "$(dirname "$0")"/*.sh 2>/dev/null; xattr -dr com.apple.quarantine "$(dirname "$0")" 2>/dev/null
# Autoriser Odaiji a joindre JuxtaLink (localhost) dans Chrome et Edge - Local Network Access (Chrome 142+)
# MadeForMed / Odaiji - v1.0. Remplace chrome://flags. Preferences managees, tous utilisateurs du Mac.
ORIGINS=("https://app.odaiji.co" "https://[*.]odaiji.co" "https://[*.]madeformed.fr")
echo "Mot de passe administrateur requis."; sudo -v || exit 1
for dom in com.google.Chrome com.microsoft.Edge; do
    for key in LocalNetworkAccessAllowedForUrls LocalNetworkAllowedForUrls; do
        if [ "$1" = "--remove" ]; then sudo defaults delete "/Library/Preferences/$dom" "$key" 2>/dev/null
        else sudo defaults write "/Library/Preferences/$dom" "$key" -array "${ORIGINS[@]}"; fi
    done
    sudo chmod 644 "/Library/Preferences/$dom.plist" 2>/dev/null
done
if [ "$1" = "--remove" ]; then echo "Politiques retirees."; else
    echo "Politiques ecrites (Chrome + Edge) : ${ORIGINS[*]}"
    echo "Relancer le navigateur. Verification : chrome://policy doit lister LocalNetworkAccessAllowedForUrls."
fi
sleep 3
