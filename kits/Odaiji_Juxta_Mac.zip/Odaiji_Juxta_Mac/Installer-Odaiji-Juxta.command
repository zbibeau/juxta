#!/bin/bash
# =====================================================================
#  Odaiji_Juxta - Installation propre de JuxtaLink + plugin SSV sur macOS
#  MadeForMed / Odaiji - v0.3.1 (24/09/2026)
# =====================================================================
#  Double-clic depuis le Finder (ou : bash Installer-Odaiji-Juxta.command)
#
#  Contenu attendu du dossier :
#    installeurs/JuxtaLink*.pkg          installeur JuxtaLink
#    installeurs/SSV/<version>/          plugin SSV (ex. 4.1.1.0, avec ComposantsSV.dll)
#    OdaijiJuxta-Mac.sh                  diagnostic / reparation
#    galss-autofix.sh + .plist + Reparer-lecteur.command   auto-alignement lecteur
#
#  Deroule :
#    1. Diag AVANT (lecture seule)            -> Bureau/Avant_<mac>_<date>.txt
#    2. Installation JuxtaLink (.pkg)
#    3. Copie du plugin SSV dans l'application ; 3b. user.config MadeForMed
#    4. Corrections automatiques sures (galss.ini PC/SC, quarantaine)
#    5. Lancement JuxtaLink
#    5c. Redemarrage propre de JuxtaLink + lecture de controle
#    6. Diag APRES + verdict                  -> Bureau/Apres_<mac>_<date>.txt
#  Options : --with-autofix  installe aussi l'agent galss-autofix (lecteurs a nommage instable)
#            --no-install    saute 2 et 3 (poste deja installe : diag + corrections seulement)
#            --keep-gatekeeper-off  ne pas reactiver Gatekeeper apres le pkg Juxta (qui le desactive)
#            --avec-galss    ne PAS retirer le GALSS Juxta (par defaut : retire et bloque apres la 1re lecture,
#                            avec retour arriere automatique par le diag si la lecture echoue ensuite)
# =====================================================================
set -u
KIT="$(cd "$(dirname "$0")" && pwd)"; cd "$KIT"
WITH_AUTOFIX=0; NO_INSTALL=0; KEEP_GK_OFF=0; SANS_GALSS=1
for a in "$@"; do [ "$a" = "--with-autofix" ] && WITH_AUTOFIX=1; [ "$a" = "--no-install" ] && NO_INSTALL=1; [ "$a" = "--keep-gatekeeper-off" ] && KEEP_GK_OFF=1; [ "$a" = "--sans-galss" ] && SANS_GALSS=1; [ "$a" = "--avec-galss" ] && SANS_GALSS=0; done
APP="/Applications/JuxtaLink.app"
say_(){ printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
ok_(){ printf '    \033[32m[OK]\033[0m %s\n' "$*"; }
ko_(){ printf '    \033[31m[KO]\033[0m %s\n' "$*"; }

echo "Odaiji_Juxta - installation JuxtaLink sur $(scutil --get ComputerName 2>/dev/null)"
echo "Mot de passe administrateur requis."
sudo -v || { ko_ "Pas de droits admin."; exit 1; }
chmod +x "$KIT"/*.sh "$KIT"/*.command 2>/dev/null

# ---------------------------------------------------------------- 0. SOURCES (telechargement optionnel)
dl(){ # dl <url> <destination>  (gere les liens Google Drive et les gros fichiers)
    local url="$1" dst="$2" id=""
    if [[ "$url" =~ drive\.google\.com ]]; then
        id=$(echo "$url" | grep -oE '(/d/|id=)[A-Za-z0-9_-]{20,}' | head -1 | sed -E 's#^(/d/|id=)##')
        [ -n "$id" ] && url="https://drive.google.com/uc?export=download&id=$id&confirm=t"
        curl -L -sS -o "$dst" "$url" || return 1
        if head -c 400 "$dst" | grep -qi '<html'; then   # page de confirmation antivirus
            local tok; tok=$(grep -oE 'confirm=[A-Za-z0-9_-]+' "$dst" | head -1 | cut -d= -f2); local uuid; uuid=$(grep -oE 'name="uuid" value="[^"]+"' "$dst" | grep -oE 'value="[^"]+"' | cut -d'"' -f2)
            curl -L -sS -o "$dst" "https://drive.usercontent.google.com/download?id=$id&export=download&confirm=${tok:-t}${uuid:+&uuid=$uuid}" || return 1
        fi
    elif [[ "$url" =~ dropbox\.com ]]; then
        url="${url/\?dl=0/?dl=1}"; url="${url/&dl=0/&dl=1}"; [[ "$url" != *dl=1* ]] && url="$url?dl=1"
        curl -L -sS -o "$dst" "$url" || return 1
    else curl -L -sS -o "$dst" "$url" || return 1; fi
    [ -s "$dst" ] && ! head -c 400 "$dst" | grep -qi '<html'
}
if [ -f "$KIT/sources.conf" ]; then
    # shellcheck disable=SC1090
    . "$KIT/sources.conf"
    mkdir -p "$KIT/installeurs/SSV"
    if [ -n "${KIT_URL:-}" ] && { ! ls "$KIT"/installeurs/JuxtaLink*.pkg >/dev/null 2>&1 || ! ls -d "$KIT"/installeurs/SSV/[0-9]* >/dev/null 2>&1; }; then
        say_ "0/6  Telechargement du dossier d'installeurs (KIT_URL)"
        rm -rf /tmp/odaiji_kit; mkdir -p /tmp/odaiji_kit
        if dl "$KIT_URL" /tmp/odaiji_kit.zip && unzip -o -q /tmp/odaiji_kit.zip -d /tmp/odaiji_kit; then
            PK=$(find /tmp/odaiji_kit -iname 'JuxtaLink*.pkg' -not -path '*__MACOSX*' | head -1)
            [ -n "$PK" ] && mv -f "$PK" "$KIT/installeurs/" && ok_ "pkg : $(basename "$PK") ($(du -h "$KIT/installeurs/$(basename "$PK")" | cut -f1))" || ko_ "Aucun JuxtaLink*.pkg dans le dossier telecharge"
            SV=$(find /tmp/odaiji_kit -iname 'ComposantsSV.dll' -not -path '*__MACOSX*' | head -1)
            if [ -n "$SV" ]; then SVD=$(dirname "$SV"); SVN=$(basename "$SVD"); [[ "$SVN" =~ ^[0-9] ]] || SVN="${SSV_VERSION:-4.1.1.0}"
                rm -rf "$KIT/installeurs/SSV/$SVN"; mkdir -p "$KIT/installeurs/SSV/$SVN"; cp -R "$SVD/." "$KIT/installeurs/SSV/$SVN/"; ok_ "plugin SSV : $SVN"
            else ko_ "Aucun ComposantsSV.dll dans le dossier telecharge"; fi
            rm -rf /tmp/odaiji_kit /tmp/odaiji_kit.zip
        else ko_ "Echec du telechargement de KIT_URL"; fi
    fi
    if [ -n "${PKG_URL:-}" ] && ! ls "$KIT"/installeurs/JuxtaLink*.pkg >/dev/null 2>&1; then
        say_ "0/6  Telechargement de l'installeur JuxtaLink"
        dl "$PKG_URL" "$KIT/installeurs/JuxtaLink.pkg" && ok_ "pkg telecharge ($(du -h "$KIT/installeurs/JuxtaLink.pkg" | cut -f1))" || { ko_ "Echec du telechargement du pkg"; rm -f "$KIT/installeurs/JuxtaLink.pkg"; }
    fi
    if [ -n "${SSV_URL:-}" ] && ! ls -d "$KIT"/installeurs/SSV/[0-9]* >/dev/null 2>&1; then
        say_ "0/6  Telechargement du plugin SSV"
        if dl "$SSV_URL" /tmp/ssv.zip && unzip -o -q /tmp/ssv.zip -d "$KIT/installeurs/SSV/"; then
            rm -rf "$KIT/installeurs/SSV/__MACOSX"
            # lien de dossier Dropbox : fichiers a la racine -> on recree <version>/
            if [ -f "$KIT/installeurs/SSV/SSV.dll" ]; then
                v="${SSV_VERSION:-}"; [ -z "$v" ] && v=$(grep -o 'SOCLE_FSV" value="[^"]*"' "$KIT/installeurs/SSV/SSV.dll.config" 2>/dev/null | cut -d'"' -f4)
                [ -z "$v" ] && v="4.1.1.0"
                mkdir -p "$KIT/installeurs/SSV/$v"; find "$KIT/installeurs/SSV" -maxdepth 1 -type f -exec mv {} "$KIT/installeurs/SSV/$v/" \;
            fi
            ok_ "plugin SSV : $(ls -d "$KIT"/installeurs/SSV/[0-9]* | xargs -n1 basename)"
        else ko_ "Echec du telechargement du plugin SSV"; fi
    fi
fi

# ---------------------------------------------------------------- 1. AVANT
say_ "1/6  Diagnostic AVANT installation (lecture seule)"
JDPREFIX="Avant" bash "$KIT/OdaijiJuxta-Mac.sh" >/dev/null 2>&1
AVANT=$(ls -t "$HOME/Desktop"/Avant_*.txt 2>/dev/null | head -1); ok_ "Rapport : $AVANT"
grep -E '^\s*\[KO\]|Scenario :' "$AVANT" | head -12

# ---------------------------------------------------------------- 2. PKG
if [ $NO_INSTALL = 0 ]; then
    say_ "2/6  Installation de JuxtaLink"
    PKG=$(ls "$KIT"/installeurs/JuxtaLink*.pkg 2>/dev/null | head -1)
    if [ -z "$PKG" ]; then ko_ "Aucun installeurs/JuxtaLink*.pkg trouve"; exit 1; fi
    if pgrep -x JuxtaLink >/dev/null; then pkill -x JuxtaLink; sleep 2; fi
    sudo installer -pkg "$PKG" -target / && ok_ "JuxtaLink installe ($(defaults read "$APP/Contents/Info.plist" CFBundleShortVersionString 2>/dev/null))" || { ko_ "Echec installer -pkg"; exit 1; }
    sudo xattr -dr com.apple.quarantine "$APP" 2>/dev/null
    # Le preinstall Juxta desactive Gatekeeper sur tout le Mac (spctl --master-disable) : on le reactive.
    if [ $KEEP_GK_OFF = 0 ]; then sudo spctl --master-enable 2>/dev/null; ok_ "Gatekeeper reactive ($(spctl --status 2>&1))"; else ko_ "Gatekeeper laisse desactive (--keep-gatekeeper-off)"; fi

    # ------------------------------------------------------------ 3. SSV
    say_ "3/6  Plugin SSV"
    SSVSRC=$(ls -d "$KIT"/installeurs/SSV/[0-9]* 2>/dev/null | sort -V | tail -1)
    if [ -z "$SSVSRC" ]; then ko_ "Aucun dossier installeurs/SSV/<version> : le plugin sera telecharge a la premiere requete (necessite Internet)"
    elif [ ! -f "$SSVSRC/ComposantsSV.dll" ] || [ ! -f "$SSVSRC/SSV.dll" ]; then ko_ "Dossier SSV incomplet (ComposantsSV.dll / SSV.dll manquant) : non copie"
    else
        DST="$APP/Contents/Resources/Plugins/SSV/$(basename "$SSVSRC")"
        sudo mkdir -p "$DST" && sudo cp -R "$SSVSRC/." "$DST/" && sudo chmod -R a+rwX "$APP/Contents/Resources/Plugins" "$APP/Contents/Resources/logs" 2>/dev/null
        ok_ "Plugin SSV $(basename "$SSVSRC") copie dans $DST"
    fi
else
    say_ "2-3/6  Installation sautee (--no-install)"
fi

# ---------------------------------------------------------------- 3b. user.config
say_ "3b/6  Configuration user.config (serveurs MadeForMed)"
UC_DST=""
for c in "$APP/Contents/Resources/user.config" "$APP/Contents/MacOS/user.config" "$HOME/.config/juxta/juxtalink/user.config"; do [ -f "$c" ] && { UC_DST="$c"; break; }; done
[ -z "$UC_DST" ] && UC_DST="$APP/Contents/Resources/user.config"
if [ -f "$KIT/user.config" ]; then
    [ -f "$UC_DST" ] && sudo cp "$UC_DST" "$UC_DST.bak-$(date +%Y%m%d-%H%M)"
    sudo cp "$KIT/user.config" "$UC_DST" && sudo chmod a+rw "$UC_DST" && ok_ "user.config ecrit : $UC_DST"
    grep -E 'tokenServerUrl|updateServerUrl|port"' "$UC_DST" | sed 's/^/    /'
else ko_ "user.config absent du kit : configuration Juxta non appliquee"; fi

# ---------------------------------------------------------------- 4. FIX AUTO
say_ "4/6  Corrections automatiques sures"
echo "    (cartes CPS + Vitale inserees pour que galss.ini soit genere avec les bons noms de lecteur)"
JDPREFIX="Fix" bash "$KIT/OdaijiJuxta-Mac.sh" --auto 2>&1 | grep -E '^\s*(\[OK\]|\[KO\]|\[WARN\]|>>)' | grep -iE 'galss|quarantaine|auto|ignore' | head -12
rm -f "$HOME/Desktop"/Fix_*.txt
if [ $WITH_AUTOFIX = 1 ]; then
    mkdir -p "$HOME/Library/Application Support/MadeForMed" "$HOME/Library/LaunchAgents"
    cp "$KIT/galss-autofix.sh" "$HOME/Library/Application Support/MadeForMed/"; chmod +x "$HOME/Library/Application Support/MadeForMed/galss-autofix.sh"
    sudo chown "$USER" /Library/Preferences/galss.ini 2>/dev/null
    sed "s#__HOME__#$HOME#g" "$KIT/fr.madeformed.galss-autofix.plist" > "$HOME/Library/LaunchAgents/fr.madeformed.galss-autofix.plist"
    launchctl bootout gui/$(id -u)/fr.madeformed.galss-autofix 2>/dev/null; launchctl bootstrap gui/$(id -u) "$HOME/Library/LaunchAgents/fr.madeformed.galss-autofix.plist"
    cp "$KIT/Reparer-lecteur.command" "$HOME/Desktop/"; chmod +x "$HOME/Desktop/Reparer-lecteur.command"; xattr -d com.apple.quarantine "$HOME/Desktop/Reparer-lecteur.command" 2>/dev/null
    ok_ "Agent galss-autofix installe + icone Reparer-lecteur sur le Bureau"
fi

# ---------------------------------------------------------------- 4b. NAVIGATEURS
say_ "4b/6  Chrome / Edge : autoriser Odaiji a joindre JuxtaLink (Local Network Access)"
bash "$KIT/Autoriser-Odaiji-Chrome.command" 2>&1 | grep -v 'Mot de passe' | sed 's/^/    /'

# ---------------------------------------------------------------- 5. LANCER
say_ "5/6  Lancement de JuxtaLink"
open -a JuxtaLink 2>/dev/null; sleep 6
pgrep -x JuxtaLink >/dev/null && ok_ "JuxtaLink en cours d'execution" || ko_ "JuxtaLink ne s'est pas lance"
echo "    >>> Dans Odaiji, faire maintenant UNE lecture CPS + Vitale (declenche le plugin)."
read -r -p "    Appuyer sur Entree une fois la lecture tentee (ou tout de suite pour passer) "

# ---------------------------------------------------------------- 5b. SANS GALSS
if [ $SANS_GALSS = 1 ]; then
    say_ "5b/6  Full PC/SC (demande Juxta) : retrait du GALSS Juxta + blocage de sa reinstallation"
    JDPREFIX="Galss" bash "$KIT/OdaijiJuxta-Mac.sh" --auto --sans-galss 2>&1 | grep -E '7g|Prerequis|BLOQUER|GALSS|>>>' | head -12
    rm -f "$HOME/Desktop"/Galss_*.txt
    read -r -p "    Refaire une lecture CPS + Vitale et une ADRi dans Odaiji, puis Entree "
fi

# ---------------------------------------------------------------- 5c. REDEMARRAGE PROPRE
# Retour terrain (PC DRSAMITIER 24/09) : 1re lecture Vitale en echec, OK apres redemarrage de JuxtaLink.
# On termine toujours par un redemarrage pour charger le plugin et la configuration finale.
say_ "5c/6  Redemarrage propre de JuxtaLink"
pkill -x JuxtaLink 2>/dev/null; sleep 3
open -a JuxtaLink 2>/dev/null; sleep 10
pgrep -x JuxtaLink >/dev/null && ok_ "JuxtaLink redemarre" || ko_ "JuxtaLink ne s'est pas relance : l'ouvrir depuis Applications"
echo "    >>> Lecture de CONTROLE dans Odaiji : CPS + Vitale (les deux cartes inserees)."
read -r -p "    Entree une fois la lecture faite "

# ---------------------------------------------------------------- 6. APRES
say_ "6/6  Diagnostic APRES"
JDPREFIX="Apres" bash "$KIT/OdaijiJuxta-Mac.sh" >/dev/null 2>&1
APRES=$(ls -t "$HOME/Desktop"/Apres_*.txt 2>/dev/null | head -1); ok_ "Rapport : $APRES"
echo; grep -E 'Scenario :' "$APRES"; grep -E '^\s*\[KO\]|^\s*\[WARN\]' "$APRES" | head -10
echo
echo "Termine. Si le scenario n'est pas OK : envoyer Avant_*.txt et Apres_*.txt dans le channel Claude."
open -R "$APRES" 2>/dev/null
