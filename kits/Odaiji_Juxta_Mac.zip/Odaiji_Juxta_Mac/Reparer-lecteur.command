#!/bin/bash
# Double-clic depuis le Finder : realigne galss.ini et relance JuxtaLink.
cd "$(dirname "$0")"
echo "Verification du lecteur de cartes..."
bash "$HOME/Library/Application Support/MadeForMed/galss-autofix.sh"
echo ""
echo "Termine. Refaire une lecture de carte dans Odaiji."
echo "(Cette fenetre peut etre fermee.)"
sleep 4
