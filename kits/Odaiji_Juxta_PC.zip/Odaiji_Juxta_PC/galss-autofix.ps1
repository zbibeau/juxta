<#


=====================================================================


 galss-autofix (Windows) - Realigne galss.ini sur les fentes reelles


 MadeForMed / Odaiji - v1.0 (22/09/2026)


=====================================================================


 Detecte via certutil dans quel lecteur PC/SC se trouvent la CPS et


 la Vitale, met a jour [CANAL1]/[CANAL2] Caracteristiques de


 C:\Windows\galss.ini si necessaire, et relance JuxtaLink.


 Ne modifie rien si la config est deja correcte.


 Le reste de galss.ini (protocoles, NomLib, LAD...) est conserve tel quel.


=====================================================================


#>


param([switch]$NoRelaunch)
$Ini = "C:\Windows\galss.ini"


$Log = Join-Path $env:ProgramData "MadeForMed\galss-autofix.log"


New-Item -ItemType Directory -Force (Split-Path $Log) | Out-Null


function L { param($m) $t = (Get-Date -Format "yyyy-MM-dd HH:mm:ss") + " " + $m; Add-Content -Path $Log -Value $t -Encoding UTF8; if ($Host.Name -ne "ServerRemoteHost") { Write-Host $m } }





# --- 1. Lecteurs et cartes via certutil


$sc = & certutil -silent -scinfo 2>&1 | Out-String


$cps = ""; $vit = ""; $cur = ""; $named = @()


foreach ($line in ($sc -split "`r?`n")) {


    if     ($line -match '^\s*---\s*Lecteur\s*:\s*(.+?)\s*$') { $cur = $Matches[1]; $named += $cur }


    elseif ($line -match 'Carte\s*:\s*.*CPS')                 { $cps = $cur }


    elseif ($line -match 'Carte\s*:\s*.*Vitale')              { $vit = $cur }


}


if (-not $cps -and -not $vit) { L "Aucune carte vue par Windows, rien a faire."; exit 0 }





# --- 2. Fente manquante : on prend l'autre fente du meme lecteur physique


function PickOther($known) {


    $base = $known -replace '\s+\d+\s+\d+\s*$', ''


    $cands = $named | Where-Object { $_ -ne $known -and $_ -like ($base + "*") }


    if ($cands) { return $cands[0] } else { return "" }


}


if (-not $vit) { $vit = PickOther $cps }


if (-not $cps) { $cps = PickOther $vit }


if (-not $cps -or -not $vit) { L "Impossible d'identifier les deux fentes (CPS='$cps' Vitale='$vit')."; exit 0 }





# --- 3. Lire galss.ini et localiser les sections


if (-not (Test-Path $Ini)) { L "ERREUR : $Ini absent."; exit 1 }


$lines = Get-Content $Ini


$idx1 = -1; $idx2 = -1; $sec = ""


for ($i = 0; $i -lt $lines.Count; $i++) {


    if ($lines[$i] -match '^\s*\[(.+?)\]') { $sec = $Matches[1].ToUpper() }


    elseif ($lines[$i] -match '^\s*Caracteristiques\s*=') {


        if ($sec -eq "CANAL1") { $idx1 = $i } elseif ($sec -eq "CANAL2") { $idx2 = $i }


    }


}


if ($idx1 -lt 0 -or $idx2 -lt 0) { L "ERREUR : sections [CANAL1]/[CANAL2] avec Caracteristiques introuvables dans galss.ini."; exit 1 }


$curCps = ($lines[$idx1] -split '=', 2)[1].Trim()


$curVit = ($lines[$idx2] -split '=', 2)[1].Trim()


if ($curCps -eq $cps -and $curVit -eq $vit) { L "OK : galss.ini deja aligne (CPS='$cps', Vitale='$vit')."; exit 0 }





# --- 4. Ecrire


Copy-Item $Ini ($Ini + ".bak-" + (Get-Date -Format "yyyyMMdd-HHmmss")) -Force -ErrorAction SilentlyContinue


$lines[$idx1] = "Caracteristiques=" + $cps


$lines[$idx2] = "Caracteristiques=" + $vit


Set-Content -Path $Ini -Value $lines -Encoding Default


L "galss.ini reecrit : CPS='$cps' (etait '$curCps'), Vitale='$vit' (etait '$curVit')."





# --- 5. Relancer JuxtaLink


$exe = "C:\Program Files (x86)\Juxta\JuxtaLink\JuxtaLink.exe"


if (-not $NoRelaunch -and (Get-Process JuxtaLink -ErrorAction SilentlyContinue)) {


    Get-Process JuxtaLink | Stop-Process -Force; Start-Sleep 2


    if (Test-Path $exe) { Start-Process explorer.exe -ArgumentList ("`"" + $exe + "`"") }


    L "JuxtaLink relance."


}


exit 0


