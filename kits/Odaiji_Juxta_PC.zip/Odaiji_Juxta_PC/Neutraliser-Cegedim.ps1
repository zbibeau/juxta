<#
=====================================================================
 Neutraliser-Cegedim - MadeForMed / Odaiji - v1.0 (24/09/2026)
=====================================================================
 Empeche les residus Cegedim / jFSE / Crossway de se lancer (ClmLive, demon jFSE...)
 SANS RIEN DESINSTALLER et SANS REDEMARRAGE. Tout est journalise et reversible :
     Neutraliser-Cegedim.bat          -> neutralise
     powershell -File Neutraliser-Cegedim.ps1 -Restaurer  -> remet l'etat d'avant (support uniquement)
 Actions : entrees de demarrage (Run) et raccourcis Demarrage deplaces en sauvegarde,
           services Cegedim passes en Desactive, taches planifiees desactivees,
           processus Cegedim arretes (java seulement s'il tourne depuis un dossier Cegedim/jFSE).
 Jamais touche : outils de prise en main a distance (TeamViewer, AnyDesk...), JuxtaLink, Icanopee,
                 amelipro, composants GIE (FSV, Cryptolib, GALSS, MICA).
 A n'utiliser QUE si le medecin ne facture plus avec un logiciel Cegedim.
=====================================================================
#>
param([switch]$Restaurer)
trap { Write-Host ("`nERREUR : " + $_.Exception.Message) -ForegroundColor Red; Read-Host "Envoyer cette capture dans le channel Claude. Entree pour fermer"; exit 1 }
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { $a=@("-NoProfile","-ExecutionPolicy","Bypass","-File","`"$PSCommandPath`""); if ($Restaurer){$a+="-Restaurer"}; Start-Process powershell.exe -Verb RunAs -ArgumentList $a; exit }

$Dir = "C:\ProgramData\MadeForMed\CegedimNeutralise"; New-Item -ItemType Directory -Force $Dir | Out-Null
$Journal = Join-Path $Dir "journal.json"
$Match  = 'cegedim|clmlive|\bclm\b|jfse|crossway|resip|synchro|\bavi\b'
$Remote = 'teamviewer|anydesk|quick ?support|quickassist|assistance|splashtop|rustdesk|supremo|ammyy|vnc|logmein|bomgar|beyondtrust|remote|dameware|netviewer'
$Keep   = 'juxta|dmpconnect|icanopee|amelipro|srvsvcnam|santesocial|galss|cryptolib|cryptographiques|mica|fsv'
function OK { param($t) Write-Host "  [OK]  $t" -ForegroundColor Green }
function IN { param($t) Write-Host "        $t" }
function Target { param([string]$txt) return ($txt -match $Match -and $txt -notmatch $Remote -and $txt -notmatch $Keep) }

# ------------------------------------------------------------------ RESTAURATION
if ($Restaurer) {
    if (-not (Test-Path $Journal)) { Write-Host "Aucun journal : rien a restaurer." -ForegroundColor Yellow; Read-Host "Entree pour fermer"; exit 0 }
    $j = Get-Content $Journal -Raw | ConvertFrom-Json
    foreach ($r in @($j.Run))      { New-Item -Path $r.Key -Force -ErrorAction SilentlyContinue | Out-Null; New-ItemProperty -Path $r.Key -Name $r.Name -Value $r.Value -PropertyType String -Force | Out-Null; OK ("Demarrage restaure : " + $r.Name) }
    foreach ($l in @($j.Lnk))      { if (Test-Path $l.Backup) { Move-Item $l.Backup $l.Path -Force; OK ("Raccourci restaure : " + $l.Path) } }
    foreach ($s in @($j.Services)) { Set-Service -Name $s.Name -StartupType $s.StartMode -ErrorAction SilentlyContinue; OK ("Service " + $s.Name + " -> " + $s.StartMode) }
    foreach ($t in @($j.Tasks))    { Enable-ScheduledTask -TaskPath $t.Path -TaskName $t.Name -ErrorAction SilentlyContinue | Out-Null; OK ("Tache reactivee : " + $t.Name) }
    Rename-Item $Journal ("journal-restaure-" + (Get-Date -Format yyyyMMdd-HHmm) + ".json")
    Write-Host "`nEtat d'origine restaure. Les programmes Cegedim se relanceront a la prochaine ouverture de session." -ForegroundColor Cyan
    Read-Host "Entree pour fermer"; exit 0
}

# ------------------------------------------------------------------ INVENTAIRE
if (Test-Path $Journal) { Write-Host "Deja neutralise (journal present). Retour arriere : contacter le support MadeForMed" -ForegroundColor Yellow; Read-Host "Entree pour fermer"; exit 0 }
$runKeys = @("HKLM:\Software\Microsoft\Windows\CurrentVersion\Run","HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run","HKCU:\Software\Microsoft\Windows\CurrentVersion\Run")
$runs = @(); foreach ($k in $runKeys) { $p = Get-ItemProperty $k -ErrorAction SilentlyContinue; if ($p) { foreach ($pr in $p.PSObject.Properties | Where-Object { $_.Name -notlike 'PS*' }) { if (Target ($pr.Name + ' ' + $pr.Value)) { $runs += [pscustomobject]@{Key=$k;Name=$pr.Name;Value=[string]$pr.Value} } } } }
$startDirs = @([Environment]::GetFolderPath("CommonStartup"), [Environment]::GetFolderPath("Startup"))
$lnks = @(); foreach ($d in $startDirs) { Get-ChildItem $d -File -ErrorAction SilentlyContinue | Where-Object { Target $_.Name } | ForEach-Object { $lnks += $_ } }
$svcs = @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | Where-Object { (Target ($_.Name + ' ' + $_.DisplayName + ' ' + $_.PathName)) -and $_.StartMode -ne 'Disabled' })
$tasks = @(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.State -ne 'Disabled' -and (Target ($_.TaskName + ' ' + $_.TaskPath + ' ' + (($_.Actions | ForEach-Object { $_.Execute }) -join ' '))) })
$procs = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Path -and ((Target $_.ProcessName) -or ($_.Path -match 'CEGEDIM|JFSE|Crossway')) -and ($_.Path -notmatch $Remote) -and ($_.ProcessName -notmatch $Keep) })

Write-Host "`nNeutraliser les residus Cegedim / jFSE (sans desinstaller, sans redemarrer)" -ForegroundColor Cyan
Write-Host "A faire UNIQUEMENT si le medecin ne facture plus avec un logiciel Cegedim.`n" -ForegroundColor Yellow
IN ("Entrees de demarrage : " + $(if ($runs) { ($runs | ForEach-Object Name) -join ", " } else { "aucune" }))
IN ("Raccourcis Demarrage : " + $(if ($lnks) { ($lnks | ForEach-Object Name) -join ", " } else { "aucun" }))
IN ("Services             : " + $(if ($svcs) { ($svcs | ForEach-Object { $_.Name + " (" + $_.StartMode + ")" }) -join ", " } else { "aucun" }))
IN ("Taches planifiees    : " + $(if ($tasks) { ($tasks | ForEach-Object TaskName) -join ", " } else { "aucune" }))
IN ("Processus a arreter  : " + $(if ($procs) { ($procs | ForEach-Object { $_.ProcessName + " (" + $_.Path + ")" }) -join ", " } else { "aucun" }))
if (-not ($runs -or $lnks -or $svcs -or $tasks -or $procs)) { OK "Rien a neutraliser."; Read-Host "Entree pour fermer"; exit 0 }
try { $Host.UI.RawUI.FlushInputBuffer() } catch {}
do { $r = (Read-Host "`n>> Le medecin n'utilise plus Cegedim : neutraliser ces elements ? [o/n]").Trim() } while ($r -notmatch '^[oOnN]')
if ($r -notmatch '^[oO]') { Write-Host "Rien n'a ete modifie."; Read-Host "Entree pour fermer"; exit 0 }

# ------------------------------------------------------------------ NEUTRALISATION (journal ecrit AVANT chaque action)
$j = [ordered]@{ Date=(Get-Date).ToString("s"); Poste=$env:COMPUTERNAME; Run=@(); Lnk=@(); Services=@(); Tasks=@() }
function Save { $j | ConvertTo-Json -Depth 5 | Set-Content $Journal -Encoding UTF8 }
foreach ($x in $runs)  { $j.Run += $x; Save; Remove-ItemProperty -Path $x.Key -Name $x.Name -ErrorAction SilentlyContinue; OK ("Demarrage retire : " + $x.Name) }
foreach ($l in $lnks)  { $b = Join-Path $Dir ("lnk_" + [guid]::NewGuid().ToString("N").Substring(0,8) + "_" + $l.Name); $j.Lnk += [pscustomobject]@{Path=$l.FullName;Backup=$b}; Save; Move-Item $l.FullName $b -Force; OK ("Raccourci Demarrage mis de cote : " + $l.Name) }
foreach ($s in $svcs)  { $mode = @{Auto="Automatic";Manual="Manual";Boot="Automatic";System="Automatic"}[$s.StartMode]; if (-not $mode) { $mode = "Manual" }
                         $j.Services += [pscustomobject]@{Name=$s.Name;StartMode=$mode}; Save
                         Stop-Service -Name $s.Name -Force -ErrorAction SilentlyContinue; Set-Service -Name $s.Name -StartupType Disabled -ErrorAction SilentlyContinue; OK ("Service desactive : " + $s.Name) }
foreach ($t in $tasks) { $j.Tasks += [pscustomobject]@{Path=$t.TaskPath;Name=$t.TaskName}; Save; Disable-ScheduledTask -TaskPath $t.TaskPath -TaskName $t.TaskName -ErrorAction SilentlyContinue | Out-Null; OK ("Tache desactivee : " + $t.TaskName) }
Save
foreach ($p in $procs) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue; OK ("Processus arrete : " + $p.ProcessName) }
Write-Host "`nTermine. Rien n'a ete desinstalle. Journal : $Journal" -ForegroundColor Cyan
Write-Host "Retour arriere possible par le support MadeForMed (journal ci-dessus)." -ForegroundColor Cyan
Write-Host "Ensuite : lecture CPS + Vitale + ADRi dans Odaiji, puis Diag-seul.bat (section PERFORMANCE)."
Read-Host "Entree pour fermer"
