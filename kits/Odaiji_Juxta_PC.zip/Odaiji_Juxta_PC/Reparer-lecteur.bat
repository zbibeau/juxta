@echo off
:: Double-clic : realigne galss.ini sur le lecteur et relance JuxtaLink (demande l'UAC).
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile -ExecutionPolicy Bypass -NoExit -File \"C:\ProgramData\MadeForMed\galss-autofix.ps1\"'"
