# Catalogue des anciens logiciels metiers (MadeForMed / Odaiji).
# Un bloc par editeur. Pour chaque editeur detecte, les outils demandent :
#   "Le medecin facture-t-il ENCORE avec <Libelle> ?"   n = lancement coupe, produits MSI desinstalles (hors FSV/Cryptolib/MICA/GALSS), Dossiers en quarantaine
# Ajouter un editeur = ajouter un bloc ici (Dossiers : chemins, jokers * autorises ; Motif : expression reguliere
# qui reconnait ses programmes, services, taches et entrees de demarrage).
@{
    Editeurs = @(
        @{
            Nom      = 'Cegedim'
            Libelle  = 'un logiciel Cegedim (Crossway, MLM, Mediclick, jFSE...)'
            Dossiers = @('C:\CEGEDIM', 'C:\Program Files (x86)\CEGEDIM', 'C:\Program Files\CEGEDIM')
            Motif    = 'cegedim|clmlive|\bclm\b|jfse|crossway|resip|synchro|\bavi\b'
            Bloquants = 'MICA x64 (empeche le MICA x86 de Juxta), processus ClmLive / demon jFSE sur le lecteur'
        },
        @{
            Nom      = 'Affid'
            Libelle  = 'Affid Systemes (fsenxt)'
            Dossiers = @('C:\Program Files (x86)\Affid Syst*', 'C:\Program Files\Affid Syst*')
            Motif    = 'affid|fsenxt'
            Bloquants = 'fsenxt.exe occupe le port 1234 de JuxtaLink'
        },
        @{
            Nom      = 'Shaman'
            Libelle  = 'Shaman'
            Dossiers = @('C:\Program Files (x86)\Shaman', 'C:\Program Files\Shaman', 'C:\Shaman')
            Motif    = 'shaman|maj400'
            Bloquants = 'sesam.ini pointant sur ses anciens dossiers (C:\Program Files\sesam), galss.ini de lecteur serie'
        },
        @{
            Nom      = 'Weda'
            Libelle  = 'Weda (Vitalzen, Weda Connect)'
            Dossiers = @('C:\Program Files\Weda*', 'C:\Program Files (x86)\Weda*', 'C:\Program Files\Vitalzen*', 'C:\Program Files (x86)\Vitalzen*', 'C:\ProgramData\Weda*', 'C:\ProgramData\Vitalzen*', 'C:\Users\*\AppData\Local\Programs\*Weda*', 'C:\Users\*\AppData\Local\Programs\*Vitalzen*')
            Motif    = 'vitalzen|\bweda'
            Bloquants = 'module SESAM-Vitale concurrent (Vitalzen) sur le lecteur ; composants exacts a confirmer sur le 1er poste (28/09)'
        }
    )
}
