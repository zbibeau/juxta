# Catalogue des anciens logiciels metiers (MadeForMed / Odaiji).
# Un bloc par editeur. Pour chaque editeur detecte, les outils demandent :
#   "Le medecin facture-t-il ENCORE avec <Libelle> ?"   n = composants neutralises (rien n'est desinstalle)
# Ajouter un editeur = ajouter un bloc ici (Dossiers : chemins, jokers * autorises ; Motif : expression reguliere
# qui reconnait ses programmes, services, taches et entrees de demarrage).
@{
    Editeurs = @(
        @{
            Nom      = 'Cegedim'
            Libelle  = 'un logiciel Cegedim (Crossway, MLM, Mediclick, jFSE...)'
            Dossiers = @('C:\CEGEDIM', 'C:\Program Files (x86)\CEGEDIM', 'C:\Program Files\CEGEDIM')
            Motif    = 'cegedim|clmlive|\bclm\b|jfse|crossway|resip|synchro|\bavi\b'
            Bloquants = 'MICA x64 (empeche le MICA x86 de Juxta), processus ClmLive / demon jFSE sur le lecteur'
        },
        @{
            Nom      = 'Affid'
            Libelle  = 'Affid Systemes (fsenxt)'
            Dossiers = @('C:\Program Files (x86)\Affid Syst*', 'C:\Program Files\Affid Syst*')
            Motif    = 'affid|fsenxt'
            Bloquants = 'fsenxt.exe occupe le port 1234 de JuxtaLink'
        }
    )
}
