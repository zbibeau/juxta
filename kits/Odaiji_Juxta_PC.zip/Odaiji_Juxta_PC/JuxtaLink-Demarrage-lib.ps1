<#
 JuxtaLink-Demarrage-lib.ps1 - fonctions partagees (tache planifiee JuxtaLink sans UAC)
 Charge par Demarrage-JuxtaLink.ps1, OdaijiJuxta.ps1 et Install-OdaijiJuxta.ps1 (dot-source, sans parametre).
 Explications : voir Demarrage-JuxtaLink.ps1.
#>

function Resolve-JxExe {
    # 28/09 : JuxtaLink pas toujours dans Program Files (x86) -> processus en cours, puis registre, puis emplacements connus
    $p = Get-Process JuxtaLink -ErrorAction SilentlyContinue | Where-Object { $_.Path } | Select-Object -First 1
    if ($p) { return $p.Path }
    foreach ($h in "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*","HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*","HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*","Registry::HKEY_USERS\*\Software\Microsoft\Windows\CurrentVersion\Uninstall\*") {
        foreach ($r in @(Get-ItemProperty $h -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -match '^JuxtaLink' })) {
            foreach ($d in @($r.InstallLocation, (Split-Path ([string]$r.DisplayIcon -replace '"|,\d+$','') -Parent -ErrorAction SilentlyContinue))) { if ($d -and (Test-Path (Join-Path $d "JuxtaLink.exe"))) { return (Join-Path $d "JuxtaLink.exe") } }
        }
    }
    $cands = @("C:\Program Files (x86)\Juxta\JuxtaLink\JuxtaLink.exe", "C:\Program Files\Juxta\JuxtaLink\JuxtaLink.exe")
    $cands += @(Get-ChildItem "C:\Users\*\AppData\Local\*Juxta*\*\JuxtaLink.exe","C:\Users\*\AppData\Local\Programs\*\JuxtaLink.exe","C:\Users\*\AppData\Local\*Juxta*\JuxtaLink.exe" -ErrorAction SilentlyContinue | ForEach-Object FullName)
    foreach ($c in $cands) { if (Test-Path $c) { return $c } }
    return "C:\Program Files (x86)\Juxta\JuxtaLink\JuxtaLink.exe"
}
$Script:JxExe      = Resolve-JxExe
$Script:JxTaskPath = "\Odaiji\"
$Script:JxTaskName = "JuxtaLink"
$Script:JxBackKey  = "HKLM:\SOFTWARE\MadeForMed\JuxtaLinkDemarrage"
$Script:JxBackDir  = "C:\ProgramData\MadeForMed\JuxtaLinkDemarrage"
$Script:JxLnk      = Join-Path ([Environment]::GetFolderPath("CommonDesktopDirectory")) "JuxtaLink (Odaiji).lnk"

function Get-JxUser {
    # Utilisateur de la session ouverte (le medecin), meme si l'UAC a ete validee avec un autre compte
    $o = Get-CimInstance Win32_Process -Filter "name='explorer.exe'" -ErrorAction SilentlyContinue | Select-Object -First 1 | Invoke-CimMethod -MethodName GetOwner -ErrorAction SilentlyContinue
    if ($o -and $o.User) { $d = if ($o.Domain) { $o.Domain } else { $env:COMPUTERNAME }; return ($d + "\" + $o.User) }
    return ($env:USERDOMAIN + "\" + $env:USERNAME)
}

function Test-JxUserAdmin { param([string]$User)
    # $true / $false / $null (inconnu, ex. compte Azure AD admin via un groupe)
    try {
        $grp = (New-Object Security.Principal.SecurityIdentifier "S-1-5-32-544").Translate([Security.Principal.NTAccount]).Value.Split("\")[-1]
        $short = $User.Split("\")[-1]
        $lines = @(net localgroup "$grp" 2>$null)
        if (-not $lines.Count) { return $null }
        if ($lines | Where-Object { $_.Trim() -eq $User -or $_.Trim().Split("\")[-1] -eq $short }) { return $true }
        if ($User -match '^AzureAD\\') { return $null }
        return $false
    } catch { return $null }
}

function Get-JxTask { Get-ScheduledTask -TaskPath $Script:JxTaskPath -TaskName $Script:JxTaskName -ErrorAction SilentlyContinue }

function Test-JxTask {
    # Etat pour le diagnostic : Absente / OK / Incorrecte (+ detail)
    $t = Get-JxTask
    if (-not $t) { return [pscustomobject]@{ Etat = "Absente"; Detail = "" } }
    $act = ($t.Actions | Select-Object -First 1).Execute
    $det = "compte " + $t.Principal.UserId + ", niveau " + $t.Principal.RunLevel + ", " + $t.State
    if ($t.Principal.RunLevel -ne "Highest" -or $act -notmatch 'JuxtaLink\.exe' -or $t.State -eq "Disabled") { return [pscustomobject]@{ Etat = "Incorrecte"; Detail = $det } }
    return [pscustomobject]@{ Etat = "OK"; Detail = $det }
}

function Get-JxAutostarts { param([string]$User, [string]$UserAppData)
    # Autres lancements automatiques de JuxtaLink (hors notre tache) : cles Run + dossiers Demarrage
    $res = @()
    $runs = @("HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run")
    try { $sid = (New-Object Security.Principal.NTAccount $User).Translate([Security.Principal.SecurityIdentifier]).Value; $runs += ("Registry::HKEY_USERS\" + $sid + "\Software\Microsoft\Windows\CurrentVersion\Run") } catch { $runs += "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" }
    foreach ($k in $runs) {
        $p = Get-ItemProperty $k -ErrorAction SilentlyContinue; if (-not $p) { continue }
        foreach ($pr in $p.PSObject.Properties) { if ($pr.Name -notmatch '^PS' -and "$($pr.Value)" -match 'juxtalink') { $res += [pscustomobject]@{ Type = "Run"; Ou = $k; Nom = $pr.Name; Valeur = "$($pr.Value)" } } }
    }
    $dirs = @((Join-Path $env:ProgramData "Microsoft\Windows\Start Menu\Programs\StartUp"))
    if ($UserAppData) { $dirs += (Join-Path $UserAppData "Microsoft\Windows\Start Menu\Programs\Startup") }
    $sh = New-Object -ComObject WScript.Shell
    foreach ($d in $dirs) {
        foreach ($f in (Get-ChildItem $d -Filter *.lnk -ErrorAction SilentlyContinue)) {
            $tgt = try { $sh.CreateShortcut($f.FullName).TargetPath } catch { "" }
            if ($f.Name -match 'juxta' -or $tgt -match 'juxtalink') { $res += [pscustomobject]@{ Type = "Lnk"; Ou = $d; Nom = $f.Name; Valeur = $tgt } }
        }
    }
    return $res
}

function Install-JxTask { param([string]$User, [string]$UserAppData)
    # Retourne une liste de lignes de compte rendu ; leve une exception si la tache ne peut pas etre creee
    $out = @()
    if (-not (Test-Path $Script:JxExe)) { throw "JuxtaLink.exe introuvable ($Script:JxExe)" }
    if (-not $User) { $User = Get-JxUser }
    $adm = Test-JxUserAdmin $User
    if ($adm -eq $false) { $out += ("ATTENTION : " + $User + " n'est pas administrateur du poste : Windows demandera un mot de passe administrateur au lancement de JuxtaLink.") }

    $a = New-ScheduledTaskAction -Execute $Script:JxExe -WorkingDirectory (Split-Path $Script:JxExe)
    $t = New-ScheduledTaskTrigger -AtLogOn -User $User; $t.Delay = "PT15S"
    $p = New-ScheduledTaskPrincipal -UserId $User -LogonType Interactive -RunLevel Highest
    $s = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -StartWhenAvailable
    Register-ScheduledTask -TaskPath $Script:JxTaskPath -TaskName $Script:JxTaskName -Action $a -Trigger $t -Principal $p -Settings $s -Description "Odaiji : JuxtaLink sans fenetre UAC a l'ouverture de session (kit Odaiji_Juxta)" -Force | Out-Null
    $out += ("Tache planifiee \Odaiji\JuxtaLink creee pour " + $User + " (ouverture de session, privileges eleves, sans UAC)")

    # Autres lancements automatiques : mis de cote, jamais supprimes
    New-Item -Path $Script:JxBackKey -Force | Out-Null; New-Item -ItemType Directory -Force $Script:JxBackDir | Out-Null
    foreach ($e in (Get-JxAutostarts $User $UserAppData)) {
        if ($e.Type -eq "Run") {
            New-ItemProperty -Path $Script:JxBackKey -Name ($e.Ou + "|" + $e.Nom) -Value $e.Valeur -PropertyType String -Force | Out-Null
            Remove-ItemProperty -Path $e.Ou -Name $e.Nom -ErrorAction SilentlyContinue
            $out += ("Lancement automatique d'origine mis de cote (cle Run) : " + $e.Nom)
        } else {
            $src = Join-Path $e.Ou $e.Nom; $dst = Join-Path $Script:JxBackDir $e.Nom
            Copy-Item $src $dst -Force; Remove-Item $src -Force -ErrorAction SilentlyContinue
            New-ItemProperty -Path $Script:JxBackKey -Name ("LNK|" + $src) -Value $dst -PropertyType String -Force | Out-Null
            $out += ("Raccourci de demarrage d'origine mis de cote : " + $e.Nom)
        }
    }

    # Icone Bureau : relance sans UAC
    $sh = New-Object -ComObject WScript.Shell; $l = $sh.CreateShortcut($Script:JxLnk)
    $l.TargetPath = Join-Path $env:SystemRoot "System32\schtasks.exe"
    $l.Arguments = "/run /tn `"" + $Script:JxTaskPath + $Script:JxTaskName + "`""
    $l.IconLocation = $Script:JxExe + ",0"; $l.WindowStyle = 7; $l.Description = "Demarrer JuxtaLink (Odaiji) sans fenetre UAC"; $l.Save()
    $out += "Icone 'JuxtaLink (Odaiji)' posee sur le Bureau (relance sans UAC)"
    return $out
}

function Remove-JxTask {
    $out = @()
    if (Get-JxTask) { Unregister-ScheduledTask -TaskPath $Script:JxTaskPath -TaskName $Script:JxTaskName -Confirm:$false; $out += "Tache \Odaiji\JuxtaLink supprimee" }
    if (Test-Path $Script:JxLnk) { Remove-Item $Script:JxLnk -Force; $out += "Icone JuxtaLink (Odaiji) retiree" }
    $b = Get-ItemProperty $Script:JxBackKey -ErrorAction SilentlyContinue
    if ($b) {
        foreach ($pr in $b.PSObject.Properties) {
            if ($pr.Name -match '^PS') { continue }
            if ($pr.Name -like "LNK|*") { $src = $pr.Name.Substring(4); if (Test-Path $pr.Value) { Copy-Item $pr.Value $src -Force; $out += ("Raccourci de demarrage restaure : " + (Split-Path $src -Leaf)) } }
            else { $i = $pr.Name.LastIndexOf("|"); $k = $pr.Name.Substring(0, $i); $n = $pr.Name.Substring($i + 1); New-ItemProperty -Path $k -Name $n -Value $pr.Value -PropertyType String -Force | Out-Null; $out += ("Cle Run restauree : " + $n) }
        }
        Remove-Item $Script:JxBackKey -Force
    }
    if (-not $out) { $out += "Rien a retirer" }
    return $out
}

function Start-JxTask {
    # Demarre JuxtaLink : via la tache (sans UAC, hors arbre de processus) ; sinon via explorer.exe (session du medecin)
    if (Get-JxTask) { Start-ScheduledTask -TaskPath $Script:JxTaskPath -TaskName $Script:JxTaskName; return "tache" }
    if (Test-Path $Script:JxExe) { Start-Process explorer.exe -ArgumentList ("`"" + $Script:JxExe + "`""); return "explorer" }
    return ""
}
