<#
=====================================================================
 OdaijiJuxta (ex JuxtaDiag) - Diagnostic & reparation JuxtaLink / Vitale / lenteurs
 MadeForMed / Odaiji
=====================================================================
 Version : 0.3  (23/09/2026)
 Auteur  : Vivien + Claude

 USAGE
   Lancer-JuxtaDiag.bat       : diagnostic (lecture seule), rapport sur le Bureau
   Lancer-JuxtaDiag-FIX.bat   : reparation, confirmation a chaque etape

 CHANGELOG
   0.3.17 - 7t : tables FSV manquantes -> MSI FSV officiel installe (auto) puis sesam.ini regenere ; MSI cherche aussi dans installeurs\
   0.3.16 - sesam.ini en chemins absolus, [MGC] majuscules, log4crc.xml pour chaque version FSV ; autres sesam.ini signales
   0.3.15 - sesam.ini : verification section [MGC] / RepertoireConfigTrace / log4crc.xml (sinon regeneration 7a)
   0.3.14 - 7p : menage propose quand un ancien logiciel tient le port JuxtaLink (Neutraliser generique -Nom/-Motif)
   0.3.13 - Port JuxtaLink : detection d'un autre programme a l'ecoute (ex. fsenxt.exe Affid) -> scenario PORT
   0.3.12 - certutil -silent (aucune fenetre PIN) ; politique LNA etendue a *.juxta.cloud (DRC GERBAL, Chrome 153)
   0.3.11 - 7b : galss-autofix lance hors pipe avec delai max 60 s et sans relance JuxtaLink (blocage GERBAL)
   0.3.10 - MICA x64 retire seulement si Cegedim n'est plus utilise (question ou -SansCegedim), puis Neutraliser-Cegedim -Auto
   0.3.9 - Nouvel outil Neutraliser-Cegedim.bat (demarrage des residus coupe, sans desinstallation)
   0.3.8 - Questions : tampon clavier vide, reponse o/n obligatoire et tracee dans le rapport ; MICA x64 verifie apres retrait
   0.3.7 - MICA : apres retrait du MICA x64, vidage du cache Plugins + relance enchaines automatiquement ; questions explicites (taper o)
   0.3.6 - MICA x64 de source RarSFX desinstalle en auto ; filet GALSS_REVERT seulement hors scenarios MICA/SESAM/READER
   0.3.5 - Nettoyage : plus aucune desinstallation de produit Cegedim/jFSE (liste seulement) apres 2e redemarrage force
   0.3.4 - Correctif verdict : "Has X -or Has Y" n'evaluait que X (PowerShell) -> GALSS_MISMATCH ignore ;
           scenario GALSS aussi pour canal CPS/Vitale sur lecteur absent ; 7b utilise galss-autofix.ps1
   0.3.3 - Nettoyage securise (incident DRSAMITIER) : outils de prise en main a distance exclus (produits, dossiers,
           Run) ; desinstalleurs non-MSI listes au lieu d'etre lances en silencieux ; MSI avec REBOOT=ReallySuppress
   0.3.2 - JuxtaLink relance via explorer.exe (non eleve, session du medecin) ; verdict A_TESTER
           (poste configure sans KO mais sans lecture Vitale reussie) au lieu de UNKNOWN
   0.3.1 - -Nettoyage (Nettoyage.bat) : FSV anciennes, Cryptolib en doublon (+ reparation des
           conservees), produits/dossiers/entrees Run Cegedim-jFSE-Crossway, diagAM ; avec confirmation
         - Verification apres 7d retablie ; TABLES_X64_ONLY passe en info
   0.3  - Section 3c NAVIGATEURS : version Chrome/Edge et politique LocalNetworkAccessAllowedForUrls
          (erreurs DRC teletransmission) ; Autoriser-Odaiji-Chrome.bat
        - -SansGalss : passage Full PC/SC (prerequis lecteur PC/SC + Cryptolib non GALSS,
          desinstallation GALSS x86 Juxta uniquement, residus *w32, BLOQUERINSTALLEGALSS=true) ;
          diag : etat GALSS x86 / cle de blocage / retour du GALSS apres MAJ plugin
        - Renomme OdaijiJuxta ; parametres -Auto (corrections sures sans question),
          -Prefix (nom du rapport Avant/Apres), -UserAppData (profil du medecin si UAC autre compte)
        - Section 3b ICANOPEE : DmpConnect-JS2 installe/actif/ports/pile x64/erreurs log ;
          GALSS et Cryptolib etiquetes Juxta (x86) ou Icanopee (x64)
        - Section PERFORMANCE : durees requete->reponse par action (ADRi, FSE, lecture)
          mesurees dans le log JuxtaLink, alerte si > 3 s
        - Decodage des reponses base64 du log : champ "diagnostic" en clair
          (ex. rejet ADRi "FINESS / numero praticien")
        - sesam.ini : verification que les repertoires declares existent
        - galss.ini : canaux pointant sur un lecteur absent, canal Vitale sur
          interface sans contact (CL), canaux inutiles
        - CertPropSvc, antivirus installes, Cryptolib en double
        - Correctifs : parsing certutil (accents/OEM), version FSV
        - Fix : sesam.ini recree dans tous les scenarios ou il manque
        - Tables FSV : inventaire x86/x64, detection sesam.ini pointant sur la mauvaise
          arborescence (SESAM_WRONG_ARCH) ; le fix 7a ecrit des chemins de tables RESOLUS
          (celles qui existent), cree log4crc.xml et la cle registre GIE
        - Fix 7a-bis : installation/reparation FSV via un fsv*.msi depose a cote du script
          (x86 prefere, x64 accepte) ; cle registre GIE FSV verifiee
   0.2  - Coherence galss.ini <-> lecteur, pile 64 bits, processus concurrents
   0.1  - Premiere version : diag complet + fix MICA x64 / sesam.ini
=====================================================================
#>
[CmdletBinding()]
param([switch]$Fix, [switch]$NoPause, [switch]$Auto, [switch]$SansGalss, [switch]$Nettoyage, [switch]$SansCegedim, [switch]$LibererPort, [string]$Prefix = "OdaijiJuxta", [string]$UserAppData = "")

trap { Write-Host ("`nERREUR : " + $_.Exception.Message) -ForegroundColor Red; Write-Host ($_.InvocationInfo.PositionMessage) -ForegroundColor DarkGray; try { Add-Content -Path $Report -Value ("ERREUR SCRIPT : " + $_.Exception.Message + " | " + $_.InvocationInfo.PositionMessage) } catch {}; if (-not ($Auto -or $NoPause)) { Read-Host "Envoyer cette capture dans le channel Claude. Entree pour fermer" }; exit 1 }

$Script:Version = "0.3.17"

# --- Auto-elevation
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    $a = @("-NoProfile","-ExecutionPolicy","Bypass","-File","`"$PSCommandPath`""); if ($Fix) { $a += "-Fix" }; if ($NoPause) { $a += "-NoPause" }; if ($Auto) { $a += "-Auto" }; if ($SansGalss) { $a += "-SansGalss" }; if ($Nettoyage) { $a += "-Nettoyage" }; if ($SansCegedim) { $a += "-SansCegedim" }; if ($LibererPort) { $a += "-LibererPort" }; $a += @("-Prefix",$Prefix); if ($UserAppData) { $a += @("-UserAppData","`"$UserAppData`"") }
    Start-Process powershell.exe -Verb RunAs -ArgumentList $a; exit
}

# --- Utilitaires
$Desktop = [Environment]::GetFolderPath("Desktop"); $Stamp = Get-Date -Format "yyyyMMdd-HHmm"
if (-not $UserAppData) { $UserAppData = $env:APPDATA }
if ($Auto -or $Nettoyage) { $Fix = $true }
$Report  = Join-Path $Desktop ("{0}_{1}_{2}.txt" -f $Prefix, $env:COMPUTERNAME, $Stamp)
$Script:Findings = @()
function W    { param([string]$t="", [string]$c="Gray") Write-Host $t -ForegroundColor $c; Add-Content -Path $Report -Value $t -Encoding UTF8 }
function H1   { param($t) W ""; W ("=" * 70) "Cyan"; W ("  " + $t) "Cyan"; W ("=" * 70) "Cyan" }
function H2   { param($t) W ""; W ("--- " + $t) "Yellow" }
function OK   { param($t) W ("  [OK]   " + $t) "Green" }
function WARN { param($t) W ("  [WARN] " + $t) "Yellow" }
function KO   { param($t) W ("  [KO]   " + $t) "Red" }
function INFO { param($t) W ("         " + $t) "Gray" }
function Finding { param($Code,$Level,$Msg) $Script:Findings += [pscustomobject]@{Code=$Code;Level=$Level;Msg=$Msg} }
function Has  { param($Code) return [bool]($Script:Findings | Where-Object Code -eq $Code) }
function Confirm-Step { param([string]$q, [switch]$Safe)
    if ($Auto) { if ($Safe) { W (">> " + $q + " -> oui (auto)") "Magenta"; return $true } else { W (">> " + $q + " -> ignore en mode auto (a valider par un humain)") "Yellow"; return $false } }
    # DRPARDON 24/09 : "o" tape mais action non executee -> on vide les touches deja tapees, on exige o ou n,
    # et la reponse est ecrite dans le rapport (preuve de ce qui a ete choisi).
    try { $Host.UI.RawUI.FlushInputBuffer() } catch {}
    do { $r = (Read-Host ("`n>> " + $q + " [o/n]")).Trim() } while ($r -notmatch '^[oOyYnN]')
    $yes = ($r -match '^[oOyY]'); Add-Content -Path $Report -Value (">> " + $q + " -> " + $(if ($yes) { "oui" } else { "non" })) -Encoding UTF8
    return $yes }
function Expand { param($p) [Environment]::ExpandEnvironmentVariables($p) }

$Paths = @{
    JuxtaExe = "C:\Program Files (x86)\Juxta\JuxtaLink\JuxtaLink.exe"
    JuxtaLog = Join-Path $UserAppData "Juxta\JuxtaLink\logs\trace.txt"
    PlugDir  = Join-Path $UserAppData "juxta\juxtalink\Plugins"
    SanteX86 = "C:\Program Files (x86)\santesocial"; SanteX64 = "C:\Program Files\santesocial"
    SesamIni = "C:\Windows\sesam.ini"; GalssIni = "C:\Windows\galss.ini"
    MicaLog  = Join-Path $env:LOCALAPPDATA "santesocial\mica\mica.log"
}
$Hives = @("HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*","HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*","HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*")

"" | Set-Content -Path $Report -Encoding UTF8
H1 ("OdaijiJuxta v" + $Script:Version + " - " + (Get-Date -Format "dd/MM/yyyy HH:mm"))
INFO ("Poste : " + $env:COMPUTERNAME + "   Utilisateur : " + $env:USERNAME + "   Mode : " + $(if ($Fix) { "REPARATION" } else { "DIAGNOSTIC" }))
INFO ("Rapport : " + $Report)

# ====================================================================
H1 "1. SYSTEME"
# ====================================================================
$os = Get-CimInstance Win32_OperatingSystem
INFO ("Windows : " + $os.Caption + " " + $os.Version + " (" + $os.OSArchitecture + ")   Boot : " + $os.LastBootUpTime.ToString("dd/MM HH:mm"))
$svc = Get-Service SCardSvr -ErrorAction SilentlyContinue
if ($svc -and $svc.Status -eq "Running") { OK "SCardSvr : Running" } else { KO "SCardSvr absent/arrete"; Finding "SCARDSVR" "KO" "Service carte a puce non demarre" }
$cps = Get-Service CertPropSvc -ErrorAction SilentlyContinue
if ($cps) { INFO ("CertPropSvc : " + $cps.Status + " / " + $cps.StartType + "  (lit tous les certificats CPS a l'insertion ; source de lenteur possible)") }
try { $av = Get-CimInstance -Namespace root\SecurityCenter2 -ClassName AntiVirusProduct -ErrorAction Stop | Select-Object -ExpandProperty displayName
      INFO ("Antivirus : " + ($av -join ", ")) ; if ($av -notmatch '^Windows Defender$' -and $av.Count) { Finding "AV_TIERS" "INFO" ("Antivirus tiers : " + ($av -join ", ")) } } catch {}

# ====================================================================
H1 "2. LECTEURS ET CARTES"
# ====================================================================
Get-PnpDevice -Class SmartCardReader -ErrorAction SilentlyContinue | ForEach-Object { INFO ("PnP : " + $_.FriendlyName + " [" + $_.Status + "]") }
H2 "certutil -scinfo (resume)"
$sc = (& certutil -silent -scinfo 2>&1 | Out-String) -replace '[\u00A0\u00E1\u00FF]', ' '
$Script:Readers = @(); $Script:CpsReader = ""; $Script:VitReader = ""; $cur = ""
foreach ($line in ($sc -split "`r?`n")) {
    if     ($line -match '^\s*---\s*Lecteur\W*:\s*(.+?)\s*$') { $cur = $Matches[1]; $Script:Readers += $cur; INFO ("Lecteur : " + $cur) }
    elseif ($line -match 'Carte\W*:\s*(.*CPS.*)$')           { $Script:CpsReader = $cur; OK ("  CPS dans '" + $cur + "'") }
    elseif ($line -match 'Carte\W*:\s*(.*Vitale.*)$')        { $Script:VitReader = $cur; OK ("  Vitale dans '" + $cur + "'") }
    elseif ($line -match 'SCARD_STATE_(PRESENT|INUSE|EMPTY|UNPOWERED)') { INFO ("  " + $line.Trim()) }
    elseif ($line -match 'partag\W+e par un autre processus') { WARN ("  '" + $cur + "' : carte tenue par un autre processus (acces exclusif SSV retarde)"); Finding "CARD_SHARED" "WARN" ("Carte partagee dans " + $cur) }
}
if (-not $Script:CpsReader) { KO "CPS non vue par Windows"; Finding "NO_CPS" "KO" "CPS non detectee" }
if (-not $Script:VitReader) { WARN "Vitale non identifiee par certutil (peut etre presente mais non reconnue : voir statut PRESENT ci-dessus)" }

# ====================================================================
H1 "3. PILE SESAM-VITALE"
# ====================================================================
H2 "Dossiers"
foreach ($p in @($Paths.SanteX86, $Paths.SanteX64)) { if (Test-Path $p) { INFO ($p + " -> " + ((Get-ChildItem $p -Directory -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name) -join ", ")) } else { INFO ($p + " -> absent") } }
$fsvX86 = @(Get-ChildItem (Join-Path $Paths.SanteX86 "fsv") -Directory -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name | Sort-Object -Descending)
$FsvVersion = if ($fsvX86.Count) { $fsvX86[0] } else { "1.40.14" }
if ($fsvX86.Count) { OK ("FSV x86 : " + ($fsvX86 -join ", ") + "  (utilisee : " + $FsvVersion + ")") } else { KO "FSV x86 absentes"; Finding "NO_FSV_X86" "KO" "FSV 32 bits absentes" }
if (Test-Path $Paths.SanteX64) { WARN "Pile 64 bits presente (Program Files\santesocial)"; Finding "STACK_X64" "WARN" "Pile 64 bits presente" }
H2 "Tables FSV disponibles (donnees identiques x86/x64)"
$Script:TableDir = @{}
foreach ($t in "ssv","srt","sts") {
    $c86 = Join-Path $Paths.SanteX86 ("fsv\" + $FsvVersion + "\" + $t); $c64 = Join-Path $Paths.SanteX64 ("fsv\" + $FsvVersion + "\" + $t)
    $n86 = if (Test-Path $c86) { (Get-ChildItem $c86 -File -Recurse -ErrorAction SilentlyContinue).Count } else { -1 }
    $n64 = if (Test-Path $c64) { (Get-ChildItem $c64 -File -Recurse -ErrorAction SilentlyContinue).Count } else { -1 }
    $pick = if ($n86 -gt 0) { $c86 } elseif ($n64 -gt 0) { $c64 } else { "" }
    $Script:TableDir[$t] = $pick
    INFO (("{0,-4} x86: {1,-8} x64: {2,-8} -> {3}" -f $t, $(if ($n86 -lt 0) { "absent" } else { "$n86 fich." }), $(if ($n64 -lt 0) { "absent" } else { "$n64 fich." }), $(if ($pick) { $pick } else { "AUCUNE TABLE" })))
    if (-not $pick) { KO ("Tables " + $t + " introuvables des deux cotes"); Finding "NO_TABLES" "KO" ("Tables FSV " + $t + " absentes") }
    elseif ($n86 -le 0) { WARN ("Tables " + $t + " uniquement en x64 : sesam.ini doit pointer sur Program Files\ (pas x86)"); Finding "TABLES_X64_ONLY" "WARN" ("Tables " + $t + " seulement en 64 bits") }
}

H2 "MICA"
$micaX86 = Get-ChildItem $Paths.SanteX86 -Recurse -Include mica.dll -ErrorAction SilentlyContinue
if ($micaX86) { OK ("mica.dll x86 : " + $micaX86[0].FullName) } else { KO "mica.dll x86 ABSENT"; Finding "NO_MICA_X86" "KO" "mica.dll 32 bits absent" }

H2 "Produits GIE / Cryptolib / GALSS inscrits"
$gie = Get-ItemProperty $Hives -ErrorAction SilentlyContinue | Where-Object { $_.Publisher -like "*GIE*" -or $_.DisplayName -match 'mica|fsv|galss|cryptolib|cps' } | Select-Object DisplayName, DisplayVersion, PSChildName, InstallLocation, InstallSource
$Script:MicaX64Product = $null
foreach ($g in $gie) {
    $who = ""
    if ($g.DisplayName -match 'galss|cryptolib') {
        if ($g.InstallSource -match 'DmpConnect|icanopee' -or ($g.InstallLocation -like "C:\Program Files\*" -and $g.InstallLocation -notlike "*(x86)*") -or $g.DisplayName -match 'x64') { $who = "  [Icanopee / DmpConnect - x64]" } else { $who = "  [Juxta / SSV - x86]" }
    }
    INFO (("{0,-28} {1,-12} {2}{3}" -f $g.DisplayName, $g.DisplayVersion, $g.PSChildName, $who)); if ($g.InstallSource) { INFO ("    src : " + $g.InstallSource) }
    if ($g.DisplayName -match '^mica' -and $g.DisplayName -match 'x64') { $Script:MicaX64Product = $g }
}
if ($Script:MicaX64Product) { WARN "MICA x64 inscrit (bloque l'installation de MICA x86 : erreur 1638)"; Finding "MICA_X64" "WARN" "MICA x64 inscrit" }
$Script:GalssX86 = @($gie | Where-Object { $_.DisplayName -match 'galss' -and -not ($_.InstallSource -match 'DmpConnect|icanopee' -or $_.DisplayName -match 'x64' -or ($_.InstallLocation -like "C:\Program Files\*" -and $_.InstallLocation -notlike "*(x86)*")) })
$Script:BloqGalss = @(Get-ChildItem (Join-Path $Paths.PlugDir "SSV") -Recurse -Filter SSV.dll.config -ErrorAction SilentlyContinue | ForEach-Object { $v = (Select-String $_.FullName -Pattern 'BLOQUERINSTALLEGALSS"\s+value="(\w+)"').Matches; if ($v) { $v[0].Groups[1].Value } })
H2 "GALSS Juxta (x86) - politique Full PC/SC"
if ($Script:GalssX86.Count) { INFO ("GALSS x86 installe : " + (($Script:GalssX86 | ForEach-Object { $_.DisplayName + " " + $_.DisplayVersion }) -join ", ")) } else { INFO "GALSS x86 absent (mode Full PC/SC)" }
INFO ("BLOQUERINSTALLEGALSS dans le plugin SSV : " + $(if ($Script:BloqGalss.Count) { $Script:BloqGalss -join "," } else { "(plugin non installe)" }))
if ($Script:GalssX86.Count -and ($Script:BloqGalss -contains "true")) { WARN "GALSS x86 revenu alors que sa reinstallation est bloquee : mise a jour du plugin ? a re-desinstaller"; Finding "GALSS_X86_BACK" "WARN" "GALSS x86 reinstalle malgre le blocage" }
if ($SansGalss -and $Script:GalssX86.Count) { Finding "GALSS_X86_TODO" "INFO" "GALSS x86 a desinstaller (-SansGalss)" }
$Script:CryptoGalss = $false
$cconf = Get-ChildItem "C:\ProgramData\santesocial\CPS","C:\Program Files (x86)\santesocial\CPS" -Recurse -Include cps3_pkcs11*.ini,cps3_pkcs11*.conf,*.ini -ErrorAction SilentlyContinue | Select-String -Pattern 'galss' -SimpleMatch | Where-Object { $_.Line -notmatch '^\s*;' }
if ($cconf) { foreach ($c in $cconf | Select-Object -First 4) { INFO ("Cryptolib config : " + $c.Filename + " : " + $c.Line.Trim()) }; if ($cconf.Line -match '(?i)galss\s*=\s*(1|true|oui)|filiere\s*=\s*galss') { $Script:CryptoGalss = $true; WARN "Cryptolib CPS x86 configuree en filiere GALSS : a reinstaller en Full PC/SC AVANT de retirer GALSS"; Finding "CRYPTO_GALSS" "WARN" "Cryptolib en mode GALSS" } }
$cryptos = @($gie | Where-Object DisplayName -match 'cryptolib')
if ($cryptos.Count -gt 1) { WARN ("Cryptolib installee " + $cryptos.Count + " fois : " + (($cryptos | ForEach-Object { $_.DisplayName + " " + $_.DisplayVersion }) -join " | ")); Finding "CRYPTO_MULTI" "INFO" "Plusieurs Cryptolib" }

H2 "sesam.ini"
$others = @("C:\ProgramData\santesocial","C:\Program Files (x86)\santesocial","C:\Program Files\santesocial") | ForEach-Object { Get-ChildItem $_ -Recurse -Filter sesam.ini -ErrorAction SilentlyContinue } | ForEach-Object FullName
if ($others) { foreach ($o in $others) { WARN ("Autre sesam.ini sur le poste : " + $o + " (verifier lequel la FSV utilise)") } }
$Script:SesamBad = $false
if (Test-Path $Paths.SesamIni) {
    $ini = Get-Content $Paths.SesamIni -ErrorAction SilentlyContinue
    if (($ini | Measure-Object -Character).Characters -lt 50) { KO "sesam.ini VIDE"; Finding "SESAM_EMPTY" "KO" "sesam.ini vide"; $Script:SesamBad = $true }
    else {
        foreach ($l in ($ini | Select-String 'Repertoire\w*=')) {
            $kv = $l.Line -split '=', 2; $p = Expand $kv[1].Trim()
            if (Test-Path $p) { OK ($kv[0].Trim() + " -> " + $p) }
            else {
                $alt = if ($p -match '\(x86\)') { $p -replace 'Program Files \(x86\)', 'Program Files' } else { $p -replace 'Program Files\\', 'Program Files (x86)\' }
                if ($p -ne $alt -and (Test-Path $alt)) { KO ($kv[0].Trim() + " -> " + $p + "  INEXISTANT, mais existe en " + $(if ($alt -match 'x86') { "x86" } else { "x64" }) + " : " + $alt); Finding "SESAM_WRONG_ARCH" "KO" ("sesam.ini pointe sur la mauvaise arborescence : " + $p) }
                else { KO ($kv[0].Trim() + " -> " + $p + "  INEXISTANT (SSV reessaie 10 x 500 ms)"); Finding "SESAM_PATH" "KO" ("Repertoire sesam.ini absent : " + $p) }
                $Script:SesamBad = $true
            }
        }
        # Section [MGC] (Dr Neyens 25/09 : "Section MGC absente, ou cle RepertoireConfigTrace absente, ou fichier
        # log4crc.xml non trouve a l'emplacement indique par la cle RepertoireConfigTrace")
        $sec = ""; $mgcTrace = $null; $mgcRaw = ""; $hasMgc = $false
        foreach ($ln in $ini) {
            if ($ln -match '^\s*\[(.+?)\]') { $sec = $Matches[1].Trim().ToUpper(); if ($sec -eq "MGC") { $hasMgc = $true }; continue }
            if ($sec -eq "MGC" -and $ln -match '^\s*RepertoireConfigTrace\s*=\s*(.+?)\s*$') { $mgcRaw = $Matches[1]; $mgcTrace = Expand $Matches[1] }
        }
        if (-not $hasMgc) { KO "sesam.ini : section [MGC] absente"; Finding "SESAM_MGC" "KO" "Section MGC absente"; $Script:SesamBad = $true }
        elseif (-not $mgcTrace) { KO "sesam.ini : [MGC] sans cle RepertoireConfigTrace"; Finding "SESAM_MGC" "KO" "MGC sans RepertoireConfigTrace"; $Script:SesamBad = $true }
        elseif (-not (Test-Path (Join-Path $mgcTrace "log4crc.xml"))) { KO ("log4crc.xml absent de " + $mgcTrace); Finding "SESAM_MGC" "KO" "log4crc.xml introuvable"; $Script:SesamBad = $true }
        else { OK ("[MGC] RepertoireConfigTrace -> " + $mgcTrace + " (log4crc.xml present)") }
        if ($mgcRaw -match '%') { WARN "RepertoireConfigTrace contient une variable (%...%) : certaines FSV ne la developpent pas"; Finding "SESAM_MGC" "KO" "Chemin MGC non absolu"; $Script:SesamBad = $true }
    }
} else { KO "sesam.ini ABSENT"; Finding "SESAM_MISSING" "KO" "sesam.ini absent"; $Script:SesamBad = $true }

H2 "Inscription FSV (registre GIE) et MSI disponibles"
$regFsv = @("HKLM:\SOFTWARE\WOW6432Node\GIE SESAM VITALE\FSV","HKLM:\SOFTWARE\GIE SESAM VITALE\FSV") | Where-Object { Test-Path $_ } | ForEach-Object { Get-ChildItem $_ -ErrorAction SilentlyContinue | ForEach-Object { $_.PSChildName + " (" + $(if ($_.Name -match 'WOW6432') { "x86" } else { "x64" }) + ")" } }
if ($regFsv) { INFO ("Registre GIE FSV : " + ($regFsv -join ", ")) } else { WARN "Aucune cle HKLM\SOFTWARE\GIE SESAM VITALE\FSV (FSV jamais installees par MSI officiel)"; Finding "FSV_NOREG" "INFO" "FSV non inscrites au registre GIE" }
$Script:FsvMsi = @(Get-ChildItem (Split-Path $PSCommandPath),(Join-Path (Split-Path $PSCommandPath) "installeurs") -Filter "fsv*.msi" -ErrorAction SilentlyContinue | Sort-Object { if ($_.Name -match 'x86') { 0 } else { 1 } })
if ($Script:FsvMsi.Count) { INFO ("MSI FSV disponibles a cote du script : " + (($Script:FsvMsi | ForEach-Object Name) -join ", ")) }

H2 "galss.ini (canaux vs lecteurs reels)"
$Script:GalssReader = ""; $Script:Canals = @()
if (Test-Path $Paths.GalssIni) {
    $sec = ""; $canal = $null
    foreach ($l in (Get-Content $Paths.GalssIni)) {
        if ($l -match '^\s*\[(CANAL(\d+))(\.PAD\d+(\.LAD\d+)?)?\]') { $sec = $Matches[1]; if (-not $Matches[3]) { $canal = [pscustomobject]@{Name=$Matches[1]; Reader=""; LADs=@()}; $Script:Canals += $canal } elseif ($Matches[4]) { $canal = $Script:Canals | Where-Object Name -eq $Matches[1] } }
        elseif ($l -match '^\s*\[') { $sec = "" }
        elseif ($sec -and $l -match '^\s*Caracteristiques\s*=\s*(.+)$') { ($Script:Canals | Where-Object Name -eq $sec).Reader = $Matches[1].Trim() }
        elseif ($sec -and $l -match '^\s*NomLAD\s*=\s*(.+)$' -and $canal) { $canal.LADs += $Matches[1].Trim() }
    }
    foreach ($c in $Script:Canals) {
        $present = $Script:Readers | Where-Object { $_ -eq $c.Reader }
        $tag = if ($present) { "present" } else { "ABSENT" }
        INFO (("{0} : '{1}' [{2}]  LAD: {3}" -f $c.Name, $c.Reader, $tag, ($c.LADs -join ",")))
        if (-not $present -and $Script:Readers.Count) { WARN ("  canal declare sur un lecteur absent -> timeouts GALSS"); Finding "GALSS_ABSENT_READER" "WARN" ($c.Name + " sur lecteur absent : " + $c.Reader) }
        if ($c.LADs -contains "Vitale" -and $c.Reader -match '\bCL\b|contactless|sans contact') { KO "  canal Vitale sur une interface SANS CONTACT"; Finding "GALSS_VITALE_CL" "KO" "Vitale declaree sur interface sans contact" }
        if ($c.LADs -contains "Vitale" -and $Script:VitReader -and $c.Reader -ne $Script:VitReader) { KO ("  canal Vitale = '" + $c.Reader + "' mais la Vitale est dans '" + $Script:VitReader + "'"); Finding "GALSS_MISMATCH" "KO" "galss.ini Vitale sur le mauvais lecteur"; $Script:GalssReader = $c.Reader }
        if ($c.LADs -contains "CPS" -and $Script:CpsReader -and $c.Reader -ne $Script:CpsReader) { WARN ("  canal CPS = '" + $c.Reader + "' mais la CPS est dans '" + $Script:CpsReader + "'"); Finding "GALSS_MISMATCH_CPS" "WARN" "galss.ini CPS sur le mauvais lecteur" }
    }
    if (-not (Has "GALSS_MISMATCH") -and -not (Has "GALSS_ABSENT_READER") -and -not (Has "GALSS_VITALE_CL") -and $Script:Canals.Count) { OK "galss.ini coherent avec les lecteurs presents" }
    (Get-Content $Paths.GalssIni | Select-String '^NomLib') | ForEach-Object { INFO $_.Line.Trim() }
} else { WARN "galss.ini absent" }

H2 "Processus concurrents sur le lecteur"
$conc = @(
    @{Name="dmpconnectjs_monitor";Desc="DmpConnect-JS2 (Icanopee)";Keep=$true}, @{Name="SRVSVCNAM";Desc="amelipro CNAM";Keep=$true},
    @{Name="SynchroSystray";Desc="Cegedim CLM";Keep=$false}, @{Name="ClmLive";Desc="Cegedim AVI";Keep=$false}, @{Name="MMTCServer";Desc="Cegedim CLM";Keep=$false},
    @{Name="jfse";Desc="jFSE";Keep=$false}, @{Name="java";Desc="Java (jFSE ?)";Keep=$false}, @{Name="JuxtaLink";Desc="JuxtaLink";Keep=$true})
foreach ($c in $conc) { $pr = Get-Process ($c.Name + "*") -ErrorAction SilentlyContinue
    if ($pr) { if ($c.Keep) { INFO ("actif : " + $c.Name.PadRight(22) + $c.Desc) } else { WARN ("actif : " + $c.Name.PadRight(22) + $c.Desc + "  <- residu (Neutraliser-Cegedim.bat)"); Finding ("PROC_" + $c.Name.ToUpper()) "WARN" ($c.Desc + " actif") } } }
if (Test-Path "C:\CEGEDIM\JFSE") { WARN "C:\CEGEDIM\JFSE present"; Finding "JFSE_DIR" "WARN" "Dossier jFSE present" }

# ====================================================================
H1 "3b. ICANOPEE / DmpConnect-JS2 (doit fonctionner en parallele de JuxtaLink)"
# ====================================================================
$dmpDir = "C:\Program Files (x86)\DmpConnect-JS2"; $dmpOK = $true
$dmpReg = Get-ItemProperty $Hives -ErrorAction SilentlyContinue | Where-Object DisplayName -match 'DmpConnect' | Select-Object -First 1
if ($dmpReg) { OK ("Installe : " + $dmpReg.DisplayName + " " + $dmpReg.DisplayVersion) } elseif (Test-Path $dmpDir) { INFO "Dossier present, produit non inscrit" } else { INFO "DmpConnect-JS2 non installe sur ce poste"; $dmpOK = $null }
if ($dmpOK) {
    $mon = Get-Process dmpconnectjs_monitor -ErrorAction SilentlyContinue; $js2 = Get-Process dmpconnect-js2 -ErrorAction SilentlyContinue
    if ($mon) { OK "dmpconnectjs_monitor actif" } else { WARN "dmpconnectjs_monitor non lance"; $dmpOK = $false }
    if ($js2) { OK ("dmpconnect-js2 actif (" + @($js2).Count + " processus)") } else { WARN "dmpconnect-js2 non lance"; $dmpOK = $false }
    $ports = @(); foreach ($pr in @($js2) + @($mon)) { if ($pr) { $ports += Get-NetTCPConnection -OwningProcess $pr.Id -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty LocalPort } }
    if ($ports) { OK ("Ecoute locale sur port(s) : " + (($ports | Sort-Object -Unique) -join ", ")) } elseif ($js2) { WARN "dmpconnect-js2 lance mais aucun port en ecoute"; $dmpOK = $false }
    $run = Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run","HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run","HKLM:\Software\Microsoft\Windows\CurrentVersion\Run" -ErrorAction SilentlyContinue | ForEach-Object { $_.PSObject.Properties } | Where-Object Name -match 'dmpconnect'
    if ($run) { INFO ("Demarrage auto : " + ($run.Name -join ", ")) } else { WARN "Pas d'entree de demarrage automatique DmpConnect" }
    $g64 = $gie | Where-Object { $_.DisplayName -match 'galss' -and ($_.InstallSource -match 'DmpConnect' -or $_.DisplayName -match 'x64') }
    $c64 = $gie | Where-Object { $_.DisplayName -match 'cryptolib' -and ($_.InstallSource -match 'DmpConnect' -or $_.DisplayName -match 'x64') }
    INFO ("Pile 64 bits Icanopee : GALSS " + $(if ($g64) { $g64.DisplayVersion } else { "absent" }) + " / Cryptolib " + $(if ($c64) { $c64.DisplayVersion } else { "absente" }))
    $dlog = Get-ChildItem $dmpDir, (Join-Path $env:ProgramData "DmpConnect*"), (Join-Path $env:LOCALAPPDATA "DmpConnect*") -Recurse -Include *.log -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($dlog) { INFO ("Log recent : " + $dlog.FullName + " (" + $dlog.LastWriteTime.ToString("dd/MM HH:mm") + ")"); (Get-Content $dlog.FullName -Tail 200 -ErrorAction SilentlyContinue | Select-String 'error|erreur|exception|fail' | Select-Object -Last 3) | ForEach-Object { WARN ("  " + $_.Line.Trim()) } }
    if ($dmpOK) { OK "Icanopee operationnel (processus + port)"; } else { KO "Icanopee non operationnel"; Finding "DMP_KO" "KO" "DmpConnect-JS2 non operationnel" }
}
W ""; INFO "Rappel : ne jamais desinstaller 'GALSS' ou 'Cryptolib' en bloc ; le x64 appartient a Icanopee, le x86 a Juxta."

# ====================================================================
H1 "3c. NAVIGATEURS - Local Network Access (erreurs DRC a la teletransmission)"
# ====================================================================
foreach ($b in @(@{N="Chrome";Exe="C:\Program Files\Google\Chrome\Application\chrome.exe";Exe2="C:\Program Files (x86)\Google\Chrome\Application\chrome.exe";Pol="HKLM:\SOFTWARE\Policies\Google\Chrome"},
                 @{N="Edge";Exe="C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe";Exe2="C:\Program Files\Microsoft\Edge\Application\msedge.exe";Pol="HKLM:\SOFTWARE\Policies\Microsoft\Edge"})) {
    $exe = @($b.Exe,$b.Exe2) | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $exe) { INFO ($b.N + " non installe"); continue }
    $ver = (Get-Item $exe).VersionInfo.ProductVersion; $major = [int]($ver -split '\.')[0]
    $pol = Get-ItemProperty (Join-Path $b.Pol "LocalNetworkAccessAllowedForUrls") -ErrorAction SilentlyContinue
    $urls = if ($pol) { ($pol.PSObject.Properties | Where-Object Name -match '^\d+$' | ForEach-Object Value) -join ", " } else { "" }
    if ($urls -match 'odaiji' -and $urls -match 'juxta\.cloud') { OK ($b.N + " " + $ver + " : politique Local Network Access OK (" + $urls + ")") }
    elseif ($urls -match 'odaiji') { WARN ($b.N + " " + $ver + " : politique sans *.juxta.cloud (DRC GERBAL) -> relancer Autoriser-Odaiji-Chrome.bat"); Finding ("LNA_" + $b.N.ToUpper()) "WARN" ($b.N + " : politique LNA incomplete (juxta.cloud)") }
    elseif ($major -ge 142) { KO ($b.N + " " + $ver + " : Local Network Access actif et Odaiji non autorise -> erreurs DRC possibles (Autoriser-Odaiji-Chrome.bat)"); Finding ("LNA_" + $b.N.ToUpper()) "KO" ($b.N + " sans politique Local Network Access") }
    else { INFO ($b.N + " " + $ver + " : version < 142, pas encore concerne ; politique a poser quand meme (Autoriser-Odaiji-Chrome.bat)") }
}

# ====================================================================
H1 "4. JUXTALINK"
# ====================================================================
if (Test-Path $Paths.JuxtaExe) { OK ("JuxtaLink " + (Get-Item $Paths.JuxtaExe).VersionInfo.FileVersion) } else { KO "JuxtaLink.exe introuvable"; Finding "NO_JUXTA" "KO" "JuxtaLink absent" }
if (Get-Process JuxtaLink -ErrorAction SilentlyContinue) { OK "JuxtaLink en cours d'execution" } else { WARN "JuxtaLink non lance" }
# Port d'ecoute : Odaiji appelle https://localhost:1234. Cas Dr Neyens 25/09 : fsenxt.exe (Affid Systemes) occupait
# le port 1234 -> Odaiji parlait au mauvais programme (connexion ouverte, aucune reponse, ERR_TIMED_OUT apres ~10 s).
$JxPort = 1234; try { $uc = Join-Path $UserAppData "juxta\juxtalink\user.config"; if (Test-Path $uc) { $m = Select-String $uc -Pattern 'key="port"\s+value="(\d+)"' | Select-Object -First 1; if ($m) { $JxPort = [int]$m.Matches[0].Groups[1].Value } } } catch {}
$lis = @(Get-NetTCPConnection -LocalPort $JxPort -State Listen -ErrorAction SilentlyContinue)
if (-not $lis) { WARN ("Aucun programme n'ecoute sur le port " + $JxPort + " (JuxtaLink arrete ou n'a pas pu demarrer)") }
foreach ($l in $lis) {
    $pp = Get-Process -Id $l.OwningProcess -ErrorAction SilentlyContinue
    $nm = if ($pp) { $pp.ProcessName } else { "PID " + $l.OwningProcess }
    if ($nm -match '^JuxtaLink') { OK ("Port " + $JxPort + " : JuxtaLink") }
    else {
        $path = try { $pp.Path } catch { "" }
        KO ("Port " + $JxPort + " occupe par " + $nm + " (" + $path + ") et non par JuxtaLink : Odaiji parle au mauvais programme (ERR_TIMED_OUT)")
        Finding "PORT_CONFLICT" "KO" ("Port " + $JxPort + " occupe par " + $nm)
        $Script:PortHolder = [pscustomobject]@{ Name=$nm; Path=$path; Company=$(try { $pp.MainModule.FileVersionInfo.CompanyName } catch { "" }) }
    }
}
if (Test-Path $Paths.PlugDir) { INFO ("Plugins : " + ((Get-ChildItem $Paths.PlugDir -Recurse -Directory -Depth 1 -ErrorAction SilentlyContinue | Where-Object Name -match '^\d' | ForEach-Object { $_.Parent.Name + " " + $_.Name }) -join ", ")) }

$Script:SigMica=$false; $Script:Sig1638=$false; $Script:VitaleOK=$false; $Script:CpsOK=$false; $Script:LogLines=@()
if (Test-Path $Paths.JuxtaLog) {
    $Script:LogLines = Get-Content $Paths.JuxtaLog -Tail 3000
    $tail = $Script:LogLines | Select-Object -Last 400
    $all = $tail -join "`n"
    if ($all -match 'Mica\.\.ctor')        { $Script:SigMica = $true }
    if ($all -match 'code de sortie 1638') { $Script:Sig1638 = $true }
    $lastV = $tail | Select-String 'Vitale pr.sente : (True|False)' | Select-Object -Last 1; if ($lastV -and $lastV.Line -match 'True') { $Script:VitaleOK = $true }
    $lastC = $tail | Select-String 'CPS pr.sente : (True|False)'    | Select-Object -Last 1; if ($lastC -and $lastC.Line -match 'True') { $Script:CpsOK = $true }
    H2 "Derniers etats de lecture"
    if ($lastC) { INFO $lastC.Line.Trim() }; if ($lastV) { INFO $lastV.Line.Trim() }
    if ($Script:SigMica) { KO "Signature 'Mica..ctor' (MICA introuvable)"; Finding "SIG_MICA" "KO" "Erreur Mica..ctor" }
    if ($Script:Sig1638) { KO "Signature MSI 1638 (MICA x64 bloque MICA x86)"; Finding "SIG_1638" "KO" "Erreur MSI 1638" }

    H2 "Erreurs recentes"
    $errs = $tail | Select-String '\[ERROR\]' | Select-Object -Last 5
    if ($errs) { foreach ($e in $errs) { KO $e.Line.Trim() } } else { OK "Aucune ligne [ERROR] dans les 400 dernieres lignes" }

    H2 "Diagnostics decodes des reponses (base64)"
    $b64s = $Script:LogLines | Select-String 'Reponse \(format de sortie : json\) : ([A-Za-z0-9+/=]{40,})' | Select-Object -Last 6
    $shown = 0
    foreach ($b in $b64s) {
        try { $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b.Matches[0].Groups[1].Value))
              $diag = [regex]::Match($json, '"diagnostic"\s*:\s*"([^"]+)"').Groups[1].Value
              $msg  = [regex]::Match($json, '"Message"\s*:\s*"([^"]+)"').Groups[1].Value
              $ts   = [regex]::Match($b.Line, '^\[([^\]]+)\]').Groups[1].Value
              if ($diag -or ($msg -and $msg -notmatch '^\s*$')) { $shown++; WARN ($ts + "  " + $(if ($diag) { $diag } else { $msg })); if ($diag -match 'FINESS|praticien|utilisateur') { Finding "ADRI_REJET" "KO" ("Rejet serveur : " + $diag) } }
        } catch {}
    }
    if (-not $shown) { INFO "Aucun message d'erreur serveur dans les dernieres reponses" }
} else { WARN "trace.txt absent : lancer une lecture depuis Odaiji puis relancer le diag" }

# ====================================================================
H1 "5. PERFORMANCE (durees mesurees dans le log JuxtaLink)"
# ====================================================================
$Script:Slow = @()
if ($Script:LogLines.Count) {
    $pending = $null; $rows = @()
    foreach ($l in $Script:LogLines) {
        if ($l -match '^\[(\d\d/\d\d/\d{4} \d\d:\d\d:\d\d)\].*\[CLIENT\] Requ.te : GET .*action=([A-Za-z]+)') { $pending = @{T=[datetime]::ParseExact($Matches[1],'dd/MM/yyyy HH:mm:ss',$null); A=$Matches[2]} }
        elseif ($pending -and $l -match '^\[(\d\d/\d\d/\d{4} \d\d:\d\d:\d\d)\].*Reponse envoy') { $t2=[datetime]::ParseExact($Matches[1],'dd/MM/yyyy HH:mm:ss',$null); $rows += [pscustomobject]@{Heure=$pending.T.ToString("dd/MM HH:mm:ss"); Action=$pending.A; Sec=($t2-$pending.T).TotalSeconds}; $pending=$null }
    }
    $rows = $rows | Select-Object -Last 25
    foreach ($r in $rows) { $tag = if ($r.Sec -ge 3) { " <- LENT" } else { "" }; W (("  {0}  {1,-28} {2,5:N0} s{3}" -f $r.Heure, $r.Action, $r.Sec, $tag)) $(if ($r.Sec -ge 3) { "Yellow" } else { "Gray" }) }
    $stats = $rows | Group-Object Action | ForEach-Object { [pscustomobject]@{Action=$_.Name; N=$_.Count; Moy=[math]::Round(($_.Group | Measure-Object Sec -Average).Average,1); Max=($_.Group | Measure-Object Sec -Maximum).Maximum} }
    H2 "Par action"
    foreach ($s in $stats) { INFO (("{0,-28} n={1,-3} moy={2,5} s  max={3,4} s" -f $s.Action, $s.N, $s.Moy, $s.Max)); if ($s.Moy -ge 3) { $Script:Slow += $s.Action; Finding ("SLOW_" + $s.Action.ToUpper()) "WARN" ($s.Action + " : " + $s.Moy + " s en moyenne") } }
    if (-not $rows.Count) { INFO "Aucune paire requete/reponse trouvee" }
} else { INFO "Pas de log" }

# ====================================================================
H1 "6. VERDICT"
# ====================================================================
$Script:Scenario = "UNKNOWN"
if ((Has "NO_CPS") -or (Has "SCARDSVR"))                     { $Script:Scenario = "READER"; KO "Windows ne voit pas la CPS -> lecteur / USB / pilote." }
elseif (Has "PORT_CONFLICT")                            { $Script:Scenario = "PORT";   KO "Un autre logiciel occupe le port de JuxtaLink : l'arreter (et son demarrage auto) ou le reconfigurer, puis relancer JuxtaLink." }
elseif (Has "ADRI_REJET")                                { $Script:Scenario = "ADRI";   KO "Cartes lues, mais rejet serveur ADRi (FINESS / praticien). Parametrage Odaiji ou support Juxta, rien a faire sur le poste." }
elseif ((Has "GALSS_VITALE_CL") -or (Has "GALSS_MISMATCH") -or ((Has "GALSS_ABSENT_READER") -and (Has "GALSS_MISMATCH_CPS")))  { $Script:Scenario = "GALSS";  KO "galss.ini ne decrit pas le lecteur reel (fichier partage avec Icanopee). Correction : -Fix." }
elseif ($Script:SigMica -and -not $micaX86)              { $Script:Scenario = "MICA";   KO "MICA x86 absent" + $(if ($Script:MicaX64Product) { " + MICA x64 fantome" } else { "" }) + ". Correction : -Fix." }
elseif (Has "NO_TABLES")                                { $Script:Scenario = "TABLES"; KO "Tables FSV manquantes (srt/ssv/sts) : lecture et facturation impossibles. Correction : -Fix (MSI FSV du GIE)." }
elseif ($Script:SesamBad)                                { $Script:Scenario = "SESAM";  KO "sesam.ini absent/vide/incorrect. Correction : -Fix." }
elseif ($Script:VitaleOK -and $Script:CpsOK)             { $Script:Scenario = "OK";     OK "Derniere lecture CPS + Vitale OK." }
elseif ((Test-Path $Paths.JuxtaExe) -and -not ($Script:Findings | Where-Object Level -eq "KO")) { $Script:Scenario = "A_TESTER"; OK "Poste configure, aucun blocage detecte. Pas de lecture Vitale reussie dans le log : faire une lecture CPS + Vitale dans Odaiji puis Diag-seul.bat." }
else { WARN "Cas non reconnu : envoyer ce rapport a Claude." }
if ($Script:Slow.Count) {
    W ""; WARN ("LENTEURS sur : " + ($Script:Slow -join ", ") + ". Causes candidates presentes sur ce poste :")
    $causes = @()
    if ((Has "SESAM_PATH") -or (Has "SESAM_MISSING") -or (Has "SESAM_EMPTY") -or (Has "SESAM_WRONG_ARCH") -or (Has "SESAM_MGC")) { $causes += "sesam.ini absent/incorrect ou tables introuvables (retries fichiers 10x500ms)" }
    if (Has "GALSS_ABSENT_READER") { $causes += "canal galss.ini sur lecteur absent (timeouts)" }
    if (Has "GALSS_VITALE_CL")     { $causes += "canal Vitale sur interface sans contact" }
    if (Has "CARD_SHARED")         { $causes += "carte tenue par un autre processus (retries exclusivite 10x500ms)" }
    if ($Script:Findings | Where-Object Code -like "PROC_*") { $causes += "residus editeur actifs sur le lecteur (Neutraliser-Cegedim.bat si Cegedim n'est plus utilise)" }
    if (Has "AV_TIERS")            { $causes += "antivirus tiers (exclusions santesocial/Juxta a verifier)" }
    if ($cps -and $cps.Status -eq "Running") { $causes += "CertPropSvc actif (test : Stop-Service CertPropSvc)" }
    if (Has "CRYPTO_MULTI")        { $causes += "Cryptolib en double" }
    if ($Script:Slow -contains "PatientAdrSilent" -and -not $causes) { $causes += "aucune cause locale trouvee -> reseau/proxy/TLS vers ADRi" }
    foreach ($c in $causes) { INFO ("  - " + $c) }
}
# Filet de securite Full PC/SC : blocage GALSS pose mais lecture en echec -> retour a false
# DRPARDON 24/09 : le filet se declenchait alors que l'echec venait de MICA -> uniquement si aucune autre cause connue
if (($Script:BloqGalss -contains "true") -and -not $Script:GalssX86.Count -and -not ($Script:CpsOK -and $Script:VitaleOK) -and $Script:LogLines.Count -and ($Script:Scenario -notin @("MICA","SESAM","READER"))) {
    $recent = ($Script:LogLines | Select-Object -Last 400) -join "`n"
    if ($recent -match 'CPS pr.sente : False|Vitale pr.sente : False') {
        WARN "Lecture en echec alors que la reinstallation du GALSS est bloquee : retour a BLOQUERINSTALLEGALSS=false (filet de securite)"
        Get-ChildItem (Join-Path $Paths.PlugDir "SSV") -Recurse -Filter SSV.dll.config -ErrorAction SilentlyContinue | ForEach-Object { $t = Get-Content $_.FullName -Raw; $t = $t -replace 'BLOQUERINSTALLEGALSS"\s+value="true"', 'BLOQUERINSTALLEGALSS" value="false"'; [IO.File]::WriteAllText($_.FullName, $t, [Text.Encoding]::UTF8) }
        Finding "GALSS_REVERT" "WARN" "Blocage GALSS annule automatiquement (lecture en echec)"
        INFO "Relancer JuxtaLink et refaire une lecture ; si elle repasse, le poste a besoin du GALSS x86 : le signaler a Juxta."
    }
}
W ""; W ("Scenario : " + $Script:Scenario) "Cyan"; W "Constats :"
foreach ($f in $Script:Findings) { INFO ("  " + $f.Code.PadRight(22) + $f.Level.PadRight(6) + $f.Msg) }

# ====================================================================
if ($Fix) {
H1 "7. REPARATION"
# ====================================================================
    if ($Script:Scenario -in @("ADRI","READER","OK","UNKNOWN") -and -not $Script:SesamBad) { WARN ("Rien a reparer automatiquement pour le scenario " + $Script:Scenario + ".") }

    # 7p. Conflit de port (Dr Neyens 25/09) : comme pour Cegedim, menage propose si l'ancienne solution n'est plus utilisee
    if ((Has "PORT_CONFLICT") -and $Script:PortHolder) {
        $ph = $Script:PortHolder
        H2 ("7p. Liberer le port " + $JxPort + " (occupe par " + $ph.Name + ")")
        $sys = $ph.Name -match '^(System|svchost|Idle|lsass|services|wininit|smss|csrss)$' -or -not $ph.Path
        $dirp = if ($ph.Path) { Split-Path $ph.Path -Parent } else { "" }
        $lbl = if ($ph.Company) { $ph.Company } elseif ($dirp) { Split-Path $dirp -Leaf } else { $ph.Name }
        if ($sys) { KO ("Port tenu par un composant Windows (" + $ph.Name + ") : a traiter par le support, rien n'est modifie") }
        elseif ($dirp -match 'Juxta|DmpConnect|santesocial|TeamViewer|AnyDesk') { KO ("Programme a ne pas toucher (" + $ph.Path + ") : a traiter par le support") }
        else {
            INFO ("Programme : " + $ph.Path + "  (editeur : " + $lbl + ")")
            $go = $false
            if ($Auto) { if ($LibererPort) { $go = $true; W (">> " + $lbl + " n'est plus utilise (reponse donnee a l'installeur) -> neutralisation") "Magenta" } else { WARN "Usage de l'ancienne solution non confirme : rien n'est modifie" } }
            else { $go = Confirm-Step ("Le medecin a-t-il ARRETE d'utiliser " + $lbl + " (" + $ph.Name + ") ? (o = oui, il ne l'utilise plus)") }
            if ($go) {
                $motif = [regex]::Escape($ph.Name) + '|' + [regex]::Escape($dirp)
                $nc = Join-Path $PSScriptRoot "Neutraliser-Cegedim.ps1"
                if (Test-Path $nc) { & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $nc -Auto -Nom $lbl -Motif $motif 2>&1 | ForEach-Object { INFO ("  " + $_) } }
                Get-NetTCPConnection -LocalPort $JxPort -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue } | Where-Object { $_.ProcessName -notmatch '^JuxtaLink' } | Stop-Process -Force -ErrorAction SilentlyContinue
                Start-Sleep 2; Get-Process JuxtaLink -ErrorAction SilentlyContinue | Stop-Process -Force; Start-Sleep 2
                if (Test-Path $Paths.JuxtaExe) { Start-Process explorer.exe -ArgumentList ("`"" + $Paths.JuxtaExe + "`"") }; Start-Sleep 8
                $now = @(Get-NetTCPConnection -LocalPort $JxPort -State Listen -ErrorAction SilentlyContinue | ForEach-Object { (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).ProcessName })
                if ($now -match '^JuxtaLink') { OK ("Port " + $JxPort + " : JuxtaLink a l'ecoute. Refaire une lecture CPS dans Odaiji.") } else { KO ("Port " + $JxPort + " : " + ($now -join ", ") + " -> verifier a la main (netstat -ano | findstr :" + $JxPort + ")") }
            } elseif (-not $Auto) { KO ("Conflit : " + $lbl + " et JuxtaLink veulent le meme port " + $JxPort + ". Changer le port de l'un des deux (support editeur / Juxta).") }
        }
    }

    # 7t. Tables FSV manquantes (Dr Neyens 25/09 : srt vides en x86 ; sur GERBAL elles n'existaient qu'en x64).
    # Le MSI FSV x64 officiel du GIE (dans le kit) les fournit. Installe sans question, puis sesam.ini regenere.
    if ((Has "NO_TABLES") -and $Script:FsvMsi.Count) {
        H2 "7t. Tables FSV manquantes : installation du MSI FSV officiel (GIE)"
        $msi = $Script:FsvMsi[0]; INFO ("MSI : " + $msi.FullName)
        if (Confirm-Step "Installer les FSV du GIE pour recuperer les tables manquantes ?" -Safe) {
            $p = Start-Process msiexec.exe -ArgumentList "/i `"$($msi.FullName)`" /qn /norestart REBOOT=ReallySuppress" -Wait -PassThru
            INFO ("msiexec : " + $p.ExitCode)
            if ($p.ExitCode -eq 1638) { $p2 = Start-Process msiexec.exe -ArgumentList "/fa `"$($msi.FullName)`" /qn /norestart REBOOT=ReallySuppress" -Wait -PassThru; INFO ("reparation /fa : " + $p2.ExitCode) }
            foreach ($t in "ssv","srt","sts") {
                if ($Script:TableDir[$t]) { continue }
                $cand = @(Get-ChildItem ($Paths.SanteX86 + "\fsv"),($Paths.SanteX64 + "\fsv") -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending | ForEach-Object { Join-Path $_.FullName $t } | Where-Object { (Get-ChildItem $_ -File -Recurse -ErrorAction SilentlyContinue).Count -gt 0 })
                if ($cand) { $Script:TableDir[$t] = $cand[0]; OK ("Tables " + $t + " -> " + $cand[0]) } else { KO ("Tables " + $t + " toujours absentes apres MSI") }
            }
            $Script:SesamBad = $true   # sesam.ini regenere avec les bons chemins (le MSI peut ecrire le sien)
        }
    }

    if ($Script:SesamBad) {
        H2 ("7a. sesam.ini (FSV " + $FsvVersion + ", x86)")
        if (Confirm-Step "Recreer C:\Windows\sesam.ini et ses repertoires ?" -Safe) {
            if (Test-Path $Paths.SesamIni) { Copy-Item $Paths.SesamIni ($Paths.SesamIni + ".bak-" + $Stamp) -Force }
            $v = $FsvVersion
            $tSsv = if ($Script:TableDir["ssv"]) { $Script:TableDir["ssv"] } else { "%ProgramFiles(x86)%\santesocial\fsv\$v\ssv" }
            $tSrt = if ($Script:TableDir["srt"]) { $Script:TableDir["srt"] } else { "%ProgramFiles(x86)%\santesocial\fsv\$v\srt" }
            $tSts = if ($Script:TableDir["sts"]) { $Script:TableDir["sts"] } else { "%ProgramFiles(x86)%\santesocial\fsv\$v\sts" }
            INFO ("Tables retenues : ssv=" + $tSsv); INFO ("                  srt=" + $tSrt); INFO ("                  sts=" + $tSts)
            # Chemins ABSOLUS (Dr Neyens 25/09 : erreur MGC ; certaines FSV ne developpent pas %ALLUSERSPROFILE%)
            $pd = "C:\ProgramData\santesocial\fsv\$v"
            $tSsv = [Environment]::ExpandEnvironmentVariables($tSsv); $tSrt = [Environment]::ExpandEnvironmentVariables($tSrt); $tSts = [Environment]::ExpandEnvironmentVariables($tSts)
            $content = @"
; sesam.ini genere par JuxtaDiag v$($Script:Version) - chemins de tables resolus sur ce poste
[COMMUN]
RepertoireTravail=$pd\adm
RepertoireTable=$tSsv
ActivationTracesLog4c=0
RepertoireConfigTrace=$pd\conf

[SSV]
RepertoireTable=$tSsv
tempoexclusivite=500
repetitionexclusivite=10
tempoexclusivitePCSC=500
repetitionexclusivitePCSC=10
tempoaccesfichier=500
repetitionaccesfichier=10

[MGC]
RepertoireConfigTrace=$pd\conf

[SRT]
RepertoireTable=$tSrt
repertoiremodification=$pd\srt

[STS]
RepertoireTable=$tSts
"@
            [IO.File]::WriteAllText($Paths.SesamIni, $content, [Text.Encoding]::GetEncoding(1252))
            foreach ($d in "adm","conf","srt") { New-Item -ItemType Directory -Force (Join-Path "C:\ProgramData\santesocial\fsv\$v" $d) | Out-Null }
            $vers = @($v) + @(Get-ChildItem "C:\Program Files (x86)\santesocial\fsv","C:\Program Files\santesocial\fsv" -Directory -ErrorAction SilentlyContinue | Where-Object Name -match '^\d+\.\d+\.\d+$' | ForEach-Object Name) | Select-Object -Unique
            foreach ($vv in $vers) {
            New-Item -ItemType Directory -Force "C:\ProgramData\santesocial\fsv\$vv\conf" | Out-Null
            $l4c = "C:\ProgramData\santesocial\fsv\$vv\conf\log4crc.xml"
            if (-not (Test-Path $l4c)) { [IO.File]::WriteAllText($l4c, "<?xml version=`"1.0`" encoding=`"ISO-8859-1`"?>`r`n<!DOCTYPE log4c SYSTEM `"`">`r`n<log4c version=`"1.2.4`">`r`n  <config><bufsize>0</bufsize><debug level=`"0`"/><nocleanup>0</nocleanup><reread>1</reread></config>`r`n  <category name=`"root`" priority=`"error`"/>`r`n  <appender name=`"stderr`" type=`"stream`" layout=`"basic`"/>`r`n  <layout name=`"basic`" type=`"basic`"/>`r`n</log4c>`r`n", [Text.Encoding]::GetEncoding(1252)); INFO "log4crc.xml cree (traces desactivees)" }
            }
            $rk = "HKLM:\SOFTWARE\WOW6432Node\GIE SESAM VITALE\FSV\$v"
            if (-not (Test-Path $rk)) { New-Item -Path $rk -Force | Out-Null; New-ItemProperty -Path $rk -Name "InstallDir" -Value (Join-Path $Paths.SanteX86 "fsv\$v") -Force | Out-Null; INFO "Cle registre GIE FSV creee" }
            OK "sesam.ini ecrit"
        }
    }

    if ($Script:FsvMsi.Count -and ($Script:SesamBad -or (Has "NO_FSV_X86") -or (Has "FSV_NOREG"))) {
        H2 "7a-bis. Installer / reparer les FSV via le MSI officiel du GIE"
        $msi = $Script:FsvMsi[0]; INFO ("MSI : " + $msi.Name + "  (" + $(if ($msi.Name -match 'x86') { "32 bits, celui que JuxtaLink utilise" } else { "64 bits : recree sesam.ini et les repertoires partages, n'installe pas les DLL 32 bits" }) + ")")
        if (Confirm-Step "Lancer msiexec /i (installation ou reparation silencieuse) ?") {
            $p = Start-Process msiexec.exe -ArgumentList "/i `"$($msi.FullName)`" /qn /norestart REINSTALLMODE=amus REINSTALL=ALL" -Wait -PassThru
            INFO ("msiexec code de sortie : " + $p.ExitCode + "  (0 = OK, 1638 = deja installe -> reparation tentee, 3010 = redemarrage requis)")
            if ($p.ExitCode -eq 1638) { $p2 = Start-Process msiexec.exe -ArgumentList "/fa `"$($msi.FullName)`" /qn /norestart REBOOT=ReallySuppress" -Wait -PassThru; INFO ("reparation /fa : " + $p2.ExitCode) }
            if (Test-Path $Paths.SesamIni) { OK "sesam.ini present apres MSI" } else { WARN "sesam.ini toujours absent : utiliser 7a" }
        }
    }

    if ($Script:Scenario -eq "GALSS") {
        H2 "7b. Realigner galss.ini sur le lecteur reel"
        $af = Join-Path $PSScriptRoot "galss-autofix.ps1"
        if ((Test-Path $af) -and (Confirm-Step "Realigner galss.ini (CANAL1 CPS / CANAL2 Vitale) sur le lecteur branche (sauvegarde .bak) ?" -Safe)) {
            # GERBAL 25/09 : lance en pipe, le script restait bloque (le processus relance heritait de la sortie).
            # -> processus separe, attente du script seul, resultat lu dans son journal ; pas de relance de JuxtaLink ici (7e).
            $afLog = Join-Path $env:ProgramData "MadeForMed\galss-autofix.log"; $before = @(Get-Content $afLog -ErrorAction SilentlyContinue).Count
            $pa = Start-Process powershell.exe -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-WindowStyle","Hidden","-File","`"$af`"","-NoRelaunch") -PassThru
            if (-not $pa.WaitForExit(60000)) { try { $pa.Kill() } catch {}; WARN "galss-autofix : delai depasse (60 s), arrete" }
            @(Get-Content $afLog -ErrorAction SilentlyContinue) | Select-Object -Skip $before | ForEach-Object { INFO ("  " + $_) }
        } else {
        $target = $Script:VitReader
        if (-not $target -and (Has "GALSS_VITALE_CL")) { $target = ($Script:Readers | Where-Object { $_ -match 'Contact' -and $_ -notmatch '\bCL\b' } | Select-Object -First 1) }
        $vc = $Script:Canals | Where-Object { $_.LADs -contains "Vitale" } | Select-Object -First 1
        if ($vc -and $target) {
            INFO ("'" + $vc.Reader + "'  ->  '" + $target + "'")
            if (Confirm-Step "Modifier C:\Windows\galss.ini (sauvegarde .bak) ?" -Safe) {
                Copy-Item $Paths.GalssIni ($Paths.GalssIni + ".bak-" + $Stamp) -Force
                $g = Get-Content $Paths.GalssIni -Raw
                $other = $Script:Canals | Where-Object { $_.Reader -eq $target -and $_.Name -ne $vc.Name } | Select-Object -First 1
                if ($other) { $g = $g -replace [regex]::Escape("Caracteristiques=" + $target), "Caracteristiques=__TMP__" }
                $g = $g -replace [regex]::Escape("Caracteristiques=" + $vc.Reader), ("Caracteristiques=" + $target)
                if ($other) { $g = $g -replace "Caracteristiques=__TMP__", ("Caracteristiques=" + $vc.Reader) }
                [IO.File]::WriteAllText($Paths.GalssIni, $g, [Text.Encoding]::GetEncoding(1252))
                (Get-Content $Paths.GalssIni | Select-String 'CANAL\d\]|Caracteristiques|NomLAD') | ForEach-Object { INFO $_.Line.Trim() }
                OK "galss.ini modifie"
            }
        } else { WARN "Impossible de determiner le lecteur cible (Vitale non identifiee par certutil)" }
        }
    }

    if ($Script:Scenario -eq "MICA") {
        if ($Script:MicaX64Product) {
            H2 "7c. Desinstaller MICA x64 fantome"; INFO ("Source : " + $Script:MicaX64Product.InstallSource)
            if ($Script:MicaX64Product.InstallSource -notmatch 'CEGEDIM|JFSE') { WARN "Source non jFSE : verifier qu'aucun logiciel 64 bits n'en depend." }
            # RarSFX = installeur auto-extractible (ex-Cegedim) : meme cas que DRSAMITIER / DR-CARRE / DRPARDON
            $safeMica = ($Script:MicaX64Product.InstallSource -match 'CEGEDIM|JFSE|RarSFX')
            # DRPARDON 25/09 : apres retrait du MICA x64, le "Module lecteur de cartes" Cegedim affiche "librairie MICA
            # n'est pas installee". Regle : MICA x64 retire SEULEMENT si le medecin n'utilise plus Cegedim, et les restes
            # Cegedim sont alors neutralises dans la foulee (Neutraliser-Cegedim.ps1 -Auto).
            $cegPresent = (Test-Path "C:\CEGEDIM") -or (Test-Path "C:\Program Files (x86)\CEGEDIM") -or [bool]($Script:Findings | Where-Object Code -like "PROC_*")
            $okCeg = (-not $cegPresent) -or $SansCegedim
            if ($cegPresent -and -not $SansCegedim) {
                if ($Auto) { WARN "Restes Cegedim presents et usage de Cegedim non confirme : MICA x64 conserve (relancer avec la reponse a la question Cegedim)" }
                elseif (Confirm-Step "Le medecin a-t-il ARRETE d'utiliser tout logiciel Cegedim ? (o = oui, il n'utilise plus Cegedim)") { $okCeg = $true; $SansCegedim = $true }
                else { KO "Conflit : Cegedim a besoin du MICA x64, Juxta du MICA x86 (meme identifiant, installation impossible des deux). A remonter a Juxta." }
            }
            $safeMica = $safeMica -and $okCeg
            if ($okCeg) {
            if (Confirm-Step "Desinstaller ce MICA x64 ? (taper o puis Entree ; Entree seul = non)" -Safe:$safeMica) { $p = Start-Process msiexec.exe -ArgumentList "/x `"$($Script:MicaX64Product.PSChildName)`" /qn /norestart REBOOT=ReallySuppress" -Wait -PassThru; INFO ("msiexec : " + $p.ExitCode); $still = Get-ItemProperty $Hives -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -eq $Script:MicaX64Product.PSChildName -and $_.DisplayName -match 'x64' }
                if (-not $still) { $Script:MicaRemoved = $true; OK "MICA x64 retire : le plugin peut maintenant installer MICA x86" }
                else { KO ("MICA x64 toujours inscrit (msiexec " + $p.ExitCode + "). Commande manuelle : msiexec /x `"" + $Script:MicaX64Product.PSChildName + "`" /qn /norestart") } }
            if ($Script:MicaRemoved -and $cegPresent) {
                $nc = Join-Path $PSScriptRoot "Neutraliser-Cegedim.ps1"
                if (Test-Path $nc) { INFO "Neutralisation des restes Cegedim (evite le message 'librairie MICA n'est pas installee')"; & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $nc -Auto 2>&1 | ForEach-Object { INFO ("  " + $_) } }
            }
            }
        }
        H2 "7d. Reinstaller le plugin SSV"
        # Apres retrait du MICA x64 (DRPARDON 24/09), la reinstallation du plugin est l'etape suivante logique : sure en auto
        if (Confirm-Step "Arreter JuxtaLink, vider le cache Plugins et le relancer ? (taper o)" -Safe:([bool]$Script:MicaRemoved)) {
            Get-Process JuxtaLink -ErrorAction SilentlyContinue | Stop-Process -Force; Start-Sleep 2
            if (Test-Path $Paths.PlugDir) { Rename-Item $Paths.PlugDir ("Plugins_old-" + $Stamp) -Force }
            if (Test-Path $Paths.JuxtaExe) { Start-Process explorer.exe -ArgumentList ("`"" + $Paths.JuxtaExe + "`"") }
            W "  >>> Dans Odaiji, lancer une lecture Vitale maintenant (accepter l'UAC)." "Magenta"; if (-not $Auto) { Read-Host "Entree une fois la lecture tentee" } else { Start-Sleep 20 }
            Start-Sleep 5
            $micaNow = Get-ChildItem $Paths.SanteX86 -Recurse -Include mica.dll -ErrorAction SilentlyContinue
            if ($micaNow) { OK ("mica.dll x86 present : " + $micaNow[0].FullName) } else { KO "mica.dll x86 toujours absent : verifier Internet / UAC, puis relancer" }
            $chk = Get-Content $Paths.JuxtaLog -Tail 200 -ErrorAction SilentlyContinue | Select-String 'MICA|1638|Vitale pr.sente' | Select-Object -Last 5
            foreach ($c in $chk) { INFO $c.Line.Trim() }
            if (($chk | Out-String) -match 'Vitale pr.sente : True') { OK "LECTURE VITALE REUSSIE" } else { WARN "Refaire une lecture Vitale puis Diag-seul.bat" }
        }
    }

    if ($Script:Scenario -in @("GALSS","SESAM")) {
        H2 "7e. Relancer JuxtaLink"
        if (Confirm-Step "Relancer JuxtaLink pour recharger la configuration ?" -Safe) { Get-Process JuxtaLink -ErrorAction SilentlyContinue | Stop-Process -Force; Start-Sleep 2; if (Test-Path $Paths.JuxtaExe) { Start-Process explorer.exe -ArgumentList ("`"" + $Paths.JuxtaExe + "`"") }; OK "JuxtaLink relance. Tester CPS + Vitale dans Odaiji." }
    }
}

if ($Fix -and $SansGalss) {
    H1 "7g. PASSAGE EN FULL PC/SC (desinstallation du GALSS x86 Juxta)"
    $blockers = @()
    if (-not $Script:Readers.Count) { $blockers += "aucun lecteur PC/SC vu par Windows (lecteur serie/PSS ?)" }
    if ($Script:CryptoGalss) { $blockers += "Cryptolib CPS x86 en filiere GALSS" }
    if ($blockers.Count) { KO ("Prerequis non remplis, on ne retire pas GALSS : " + ($blockers -join " ; ")) }
    else {
        OK ("Prerequis OK : lecteur(s) PC/SC = " + ($Script:Readers -join " | ") + " ; Cryptolib sans indication GALSS")
        if ($Script:GalssX86.Count) {
            foreach ($g in $Script:GalssX86) {
                if (Confirm-Step ("Desinstaller " + $g.DisplayName + " " + $g.DisplayVersion + " (x86 Juxta) ?") -Safe) {
                    if ($g.PSChildName -match '^\{[0-9A-F-]+\}$') { $p = Start-Process msiexec.exe -ArgumentList "/x `"$($g.PSChildName)`" /qn /norestart REBOOT=ReallySuppress" -Wait -PassThru; INFO ("msiexec : " + $p.ExitCode) }
                    elseif ($g.UninstallString) { INFO ("Desinstalleur : " + $g.UninstallString); cmd /c ($g.UninstallString + " /S") }
                }
            }
            $left = Get-ChildItem "C:\Windows\SysWOW64\gal*w32*","C:\Windows\gal*w32*","C:\Windows\SysWOW64\pssinw32.dll","C:\Windows\SysWOW64\pcscw32.dll" -ErrorAction SilentlyContinue
            if ($left) { INFO ("Residus 32 bits : " + (($left | ForEach-Object Name) -join ", ")); if (Confirm-Step "Supprimer ces fichiers GALSS 32 bits residuels (galss.ini conserve pour Icanopee) ?" -Safe) { $left | Remove-Item -Force -ErrorAction SilentlyContinue; OK "Residus supprimes" } }
        } else { OK "GALSS x86 deja absent" }
        $cfgs = Get-ChildItem (Join-Path $Paths.PlugDir "SSV") -Recurse -Filter SSV.dll.config -ErrorAction SilentlyContinue
        if ($cfgs) { foreach ($c in $cfgs) { $t = Get-Content $c.FullName -Raw; if ($t -match 'BLOQUERINSTALLEGALSS"\s+value="false"') { $t = $t -replace 'BLOQUERINSTALLEGALSS"\s+value="false"', 'BLOQUERINSTALLEGALSS" value="true"'; [IO.File]::WriteAllText($c.FullName, $t, [Text.Encoding]::UTF8); OK ("BLOQUERINSTALLEGALSS=true dans " + $c.FullName) } else { INFO ("Deja bloque : " + $c.FullName) } } }
        else { WARN "Plugin SSV pas encore installe : relancer avec -SansGalss apres la premiere lecture (le plugin reinstallera GALSS entre-temps)" }
        if (Confirm-Step "Relancer JuxtaLink ?" -Safe) { Get-Process JuxtaLink -ErrorAction SilentlyContinue | Stop-Process -Force; Start-Sleep 2; if (Test-Path $Paths.JuxtaExe) { Start-Process explorer.exe -ArgumentList ("`"" + $Paths.JuxtaExe + "`"") } }
        W "  >>> Tester CPS + Vitale + une ADRi dans Odaiji, puis relancer le diag : section PERFORMANCE et 'GALSS x86 absent' attendus." "Magenta"
    }
}

if ($Fix -and $Nettoyage) {
    H1 "7h. NETTOYAGE DES RESIDUS (ex-Cegedim / jFSE / Crossway)"
    $all = Get-ItemProperty $Hives -ErrorAction SilentlyContinue | Where-Object DisplayName
    # --- FSV anciennes (autres que la version utilisee)
    $oldFsv = $all | Where-Object { $_.DisplayName -match '^fsv' -and $_.DisplayName -notmatch [regex]::Escape($FsvVersion.Replace('.','')) -and $_.DisplayName -notmatch [regex]::Escape($FsvVersion) }
    $oldFsv = $oldFsv | Where-Object { $_.DisplayName -match '1\.40\.1[0-3]' -or $_.DisplayName -match '1408' }
    foreach ($f in $oldFsv) { if (Confirm-Step ("Desinstaller " + $f.DisplayName + " (ancienne FSV, source " + $f.InstallSource + ") ?")) { INFO ("  lancement msiexec /x " + $f.DisplayName); $p = Start-Process msiexec.exe -ArgumentList "/x `"$($f.PSChildName)`" /qn /norestart REBOOT=ReallySuppress" -Wait -PassThru; INFO ("  msiexec : " + $p.ExitCode) } }
    # --- Cryptolib : garder la plus recente par architecture
    $cryptos = $all | Where-Object { $_.DisplayName -match 'Cryptographiques CPS' } | ForEach-Object { $_ | Add-Member -NotePropertyName Arch -NotePropertyValue $(if ($_.DisplayName -match 'x64') { "x64" } else { "x86" }) -PassThru | Add-Member -NotePropertyName Ver -NotePropertyValue ([version]($_.DisplayVersion -replace '[^\d\.]','')) -PassThru }
    $keep = @(); foreach ($arch in "x86","x64") { $k = $cryptos | Where-Object Arch -eq $arch | Sort-Object Ver -Descending | Select-Object -First 1; if ($k) { $keep += $k; INFO ("Cryptolib conservee (" + $arch + ") : " + $k.DisplayName) } }
    $drop = $cryptos | Where-Object { $keep.PSChildName -notcontains $_.PSChildName }
    if ($drop) {
        INFO ("Cryptolib en doublon : " + (($drop | ForEach-Object DisplayName) -join " | "))
        if (Confirm-Step ("Desinstaller ces " + @($drop).Count + " anciennes Cryptolib, puis reparer celles conservees ?")) {
            foreach ($d in ($drop | Sort-Object Ver)) { INFO ("  lancement msiexec /x " + $d.DisplayName); $p = Start-Process msiexec.exe -ArgumentList "/x `"$($d.PSChildName)`" /qn /norestart REBOOT=ReallySuppress" -Wait -PassThru; INFO ("  " + $d.DisplayName + " : msiexec " + $p.ExitCode) }
            foreach ($k in $keep) { $p = Start-Process msiexec.exe -ArgumentList "/fa `"$($k.PSChildName)`" /qn /norestart REBOOT=ReallySuppress" -Wait -PassThru; INFO ("  reparation " + $k.DisplayName + " : msiexec " + $p.ExitCode) }
        }
    } else { OK "Pas de Cryptolib en doublon" }
    # --- Produits Cegedim / Crossway / jFSE encore inscrits
    # Incident DRSAMITIER 24/09 : redemarrage force + TeamViewer disparu pendant le nettoyage.
    # Jamais d'outil de prise en main a distance ; jamais de desinstalleur non-MSI en silencieux (peut redemarrer).
    $Remote = 'teamviewer|anydesk|quick ?support|quickassist|assistance|splashtop|rustdesk|supremo|ammyy|vnc|logmein|bomgar|beyondtrust|remote|dameware|netviewer'
    $ceg = $all | Where-Object { ($_.Publisher -match 'cegedim|resip|clm' -or $_.DisplayName -match 'crossway|jfse|cegedim|clm ') -and $_.DisplayName -notmatch 'Cryptographiques' -and ($_.DisplayName + ' ' + $_.Publisher + ' ' + $_.InstallLocation + ' ' + $_.UninstallString) -notmatch $Remote }
    # 2e redemarrage force (24/09) au moment de cette etape : les desinstalleurs Cegedim (meme MSI) peuvent redemarrer
    # via leurs propres actions. On ne desinstalle plus rien ici : liste seulement, a traiter a la main hors consultation.
    if ($ceg) {
        WARN "Produits Cegedim / jFSE encore inscrits (NON desinstalles automatiquement : risque de redemarrage) :"
        foreach ($c in $ceg) { WARN ("  - " + $c.DisplayName + " " + $c.DisplayVersion + " (" + $c.Publisher + ")") }
        INFO "  -> si le medecin n'utilise plus Cegedim : Parametres > Applications, un par un, en fin de journee."
    } else { OK "Aucun produit Cegedim / jFSE inscrit" }
    # --- Dossiers residuels
    foreach ($d in "C:\CEGEDIM","C:\Program Files (x86)\CEGEDIM","C:\AVI","C:\Program Files (x86)\santesocial\diagAM") {
        if (Test-Path $d) {
            $busy = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Path -like ($d + "\*") }
            $rem = Get-ChildItem $d -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -match $Remote } | Select-Object -First 1
            if ($rem) { WARN ($d + " : contient un outil de prise en main a distance (" + $rem.Name + "), non supprime") }
            elseif ($busy) { WARN ($d + " : processus actifs (" + (($busy | ForEach-Object ProcessName) -join ",") + "), non supprime") }
            elseif (Confirm-Step ("Supprimer le dossier residuel " + $d + " ?")) { Remove-Item $d -Recurse -Force -ErrorAction SilentlyContinue; OK ("supprime : " + $d) }
        }
    }
    # --- Entrees Run Cegedim
    foreach ($h in "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run","HKLM:\Software\Microsoft\Windows\CurrentVersion\Run","HKCU:\Software\Microsoft\Windows\CurrentVersion\Run") {
        $rp = Get-ItemProperty $h -ErrorAction SilentlyContinue; if (-not $rp) { continue }
        foreach ($prop in $rp.PSObject.Properties | Where-Object { $_.Name -match 'Synchro|CLM|jfse|Cegedim' -and ($_.Name + ' ' + $_.Value) -notmatch $Remote }) { if (Confirm-Step ("Retirer l'entree de demarrage " + $prop.Name + " (" + $prop.Value + ") ?")) { Remove-ItemProperty $h -Name $prop.Name -ErrorAction SilentlyContinue; OK ("retiree : " + $prop.Name) } }
    }
    W "  >>> Refaire une lecture CPS + Vitale dans Odaiji, puis Diag-seul.bat." "Magenta"
    W "  Antivirus : en garder UN seul (decision du cabinet), via Parametres > Applications." "Yellow"
}

H1 "FIN"
W ("Rapport : " + $Report) "Cyan"; W "Copier son contenu dans le channel Claude pour analyse." "Cyan"
if (-not $NoPause) { Read-Host "`nEntree pour fermer" }
