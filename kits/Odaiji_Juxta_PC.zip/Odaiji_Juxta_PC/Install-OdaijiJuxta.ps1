<#
=====================================================================
 Odaiji_Juxta - Installation propre de JuxtaLink sur Windows
 MadeForMed / Odaiji - v0.3.2 (24/09/2026)
=====================================================================
 Lance par Installer-Odaiji-Juxta.bat (elevation UAC automatique).
 Contenu attendu du dossier :
   installeurs\SetupJuxtaLinkx86.msi   installeur JuxtaLink (WiX, 2.2.3 x86)
   installeurs\fsv-*.msi               FSV du GIE (repli si sesam.ini/tables manquent)
   user.config                          configuration MadeForMed
   OdaijiJuxta.ps1                      diagnostic / reparation
   galss-autofix.ps1 + Reparer-lecteur.bat   (option -WithAutofix)
 Deroule : 1 diag AVANT -> 2 MSI JuxtaLink -> 3 user.config -> 4 corrections auto sures -> 4b politiques Chrome/Edge
           -> 5 lancement + premiere lecture (le plugin installe FSV/GALSS/MICA/Cryptolib) -> 5a corrections rejouees
           -> 5 lancement + premiere lecture (le plugin SSV s'installe) -> 6 diag APRES
 Options : -NoInstall (poste deja equipe) ; -WithAutofix (lecteur a nommage instable)
           -AvecGalss (ne PAS retirer le GALSS x86 Juxta ; par defaut il est retire et bloque apres
                       la premiere lecture, avec retour arriere automatique si la lecture echoue ensuite)
 Le plugin SSV et ses prerequis (FSV, GALSS, MICA, Cryptolib) sont telecharges par
 JuxtaLink a la PREMIERE REQUETE : Internet requis, et un admin present pour l'UAC.
=====================================================================
#>
param([switch]$NoInstall, [switch]$WithAutofix, [switch]$AvecGalss)
trap { Write-Host ("`nERREUR : " + $_.Exception.Message) -ForegroundColor Red; Write-Host ($_.InvocationInfo.PositionMessage) -ForegroundColor DarkGray; Read-Host "Envoyer cette capture dans le channel Claude. Entree pour fermer"; exit 1 }

$Kit = Split-Path -Parent $MyInvocation.MyCommand.Path
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { $a=@("-NoProfile","-ExecutionPolicy","Bypass","-File","`"$PSCommandPath`""); if ($NoInstall){$a+="-NoInstall"}; if ($WithAutofix){$a+="-WithAutofix"}; if ($AvecGalss){$a+="-AvecGalss"}; Start-Process powershell.exe -Verb RunAs -ArgumentList $a; exit }
# Start-Process -Wait attend aussi les processus ENFANTS : si le diag relance JuxtaLink, l'installeur restait bloque
# (etape 4, DRSAMITIER 24/09). WaitForExit() n'attend que le diag lui-meme.
function Run-Diag { param($ArgList) $p = Start-Process powershell.exe -ArgumentList $ArgList -PassThru; $p.WaitForExit() }
# JuxtaLink lance via explorer.exe : non eleve, dans la session du medecin, hors arbre de processus de l'installeur
function Start-JuxtaUser { param($Exe) Start-Process explorer.exe -ArgumentList ("`"" + $Exe + "`"") }
function Say { param($t) Write-Host "`n==> $t" -ForegroundColor Cyan }
function OK  { param($t) Write-Host "    [OK]  $t" -ForegroundColor Green }
function KO  { param($t) Write-Host "    [KO]  $t" -ForegroundColor Red }

# --- Profil de l'utilisateur connecte (le medecin), meme si l'UAC a utilise un autre compte
$owner = (Get-CimInstance Win32_Process -Filter "name='explorer.exe'" | Select-Object -First 1 | Invoke-CimMethod -MethodName GetOwner)
$prof = (Get-CimInstance Win32_UserProfile | Where-Object { $_.LocalPath -like ("*\" + $owner.User) } | Select-Object -First 1).LocalPath
if (-not $prof) { $prof = $env:USERPROFILE }
$UserAppData = Join-Path $prof "AppData\Roaming"
$Desktop = Join-Path $prof "Desktop"
Write-Host "Odaiji_Juxta - installation JuxtaLink sur $env:COMPUTERNAME pour l'utilisateur $($owner.User)"
$diagArgs = @("-NoProfile","-ExecutionPolicy","Bypass","-File","`"$Kit\OdaijiJuxta.ps1`"","-NoPause","-UserAppData","`"$UserAppData`"")

# ---------------------------------------------------------------- 1. AVANT
Say "1/6  Diagnostic AVANT (lecture seule)"
Run-Diag ($diagArgs + @("-Prefix","Avant"))
$avant = Get-ChildItem "$Desktop\Avant_*.txt" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($avant) { OK "Rapport : $($avant.FullName)"; Get-Content $avant.FullName | Select-String '^\s*\[KO\]|Scenario :' | Select-Object -First 10 | ForEach-Object { Write-Host "    $($_.Line.Trim())" } }

# ---------------------------------------------------------------- 1b. ANCIENS LOGICIELS METIERS (catalogue editeurs.psd1)
# Une question par editeur detecte, posee ici une seule fois (le diag de correction tourne sans question).
$sans = @(); $garde = @(); $edDet = @()
$cat = Join-Path $Kit "editeurs.psd1"
if (Test-Path $cat) {
    $procs = Get-Process -ErrorAction SilentlyContinue
    foreach ($e in (Import-PowerShellDataFile $cat).Editeurs) {
        $found = $false
        foreach ($d in $e.Dossiers) { if (Get-Item $d -ErrorAction SilentlyContinue) { $found = $true; break } }
        if (-not $found -and ($procs | Where-Object { ($_.ProcessName + ' ' + $(try { $_.Path } catch { '' })) -match $e.Motif -and $_.ProcessName -notmatch '^JuxtaLink' })) { $found = $true }
        if ($found) { $edDet += $e }
    }
}
if ($edDet) {
    Say "1b/6  Anciens logiciels metiers detectes sur ce poste"
    Write-Host "    Si Odaiji les remplace, repondre n : leurs composants bloquants seront neutralises (rien n'est desinstalle)." -ForegroundColor Yellow
    foreach ($e in $edDet) {
        Write-Host ("    - " + $e.Nom + " : " + $e.Bloquants) -ForegroundColor DarkGray
        try { $Host.UI.RawUI.FlushInputBuffer() } catch {}
        do { $r = (Read-Host ("    Le medecin facture-t-il ENCORE avec " + $e.Libelle + " ? [o/n]")).Trim() } while ($r -notmatch '^[oOnN]')
        if ($r -match '^[nN]') { $sans += $e.Nom; OK ($e.Nom + " : plus utilise -> sera neutralise") }
        else { $garde += $e.Nom; Write-Host ("    " + $e.Nom + " encore utilise : on n'y touche pas (" + $e.Bloquants + " : risque de blocage)") -ForegroundColor Yellow }
    }
    if ($sans)  { $diagArgs += @("-SansEditeurs","`"" + ($sans -join ",") + "`"") }
    if ($garde) { $diagArgs += @("-GardeEditeurs","`"" + ($garde -join ",") + "`"") }
}

# ---------------------------------------------------------------- 1c. PORT JUXTALINK (ancienne solution a l'ecoute)
$holder = Get-NetTCPConnection -LocalPort 1234 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue } | Where-Object { $_.ProcessName -notmatch '^JuxtaLink' } | Select-Object -First 1
if ($holder) { $hp = try { $holder.Path } catch { "" }; $own = $edDet | Where-Object { ($holder.ProcessName + ' ' + $hp) -match $_.Motif } | Select-Object -First 1 }
if ($holder -and $own) {
    if ($sans -contains $own.Nom) { $diagArgs += "-LibererPort"; OK ("Port 1234 tenu par " + $holder.ProcessName + " (" + $own.Nom + ", plus utilise) : il sera libere") }
    else { Write-Host ("    Port 1234 tenu par " + $holder.ProcessName + " (" + $own.Nom + ", encore utilise) : conflit a traiter avec les editeurs.") -ForegroundColor Yellow }
} elseif ($holder) {
    $hp = try { $holder.Path } catch { "" }; $hc = try { $holder.MainModule.FileVersionInfo.CompanyName } catch { "" }
    Say ("1c/6  Le port 1234 de JuxtaLink est occupe par " + $holder.ProcessName + " (" + $(if ($hc) { $hc } else { $hp }) + ")")
    try { $Host.UI.RawUI.FlushInputBuffer() } catch {}
    do { $r = (Read-Host ("    Le medecin utilise-t-il ENCORE ce logiciel (" + $holder.ProcessName + ") ? [o/n]  (n = il sera neutralise)")).Trim() } while ($r -notmatch '^[oOnN]')
    if ($r -match '^[nN]') { $diagArgs += "-LibererPort"; OK "Il sera neutralise (sans desinstallation) pour liberer le port" }
    else { Write-Host "    Encore utilise : rien n'est modifie. Conflit de port a traiter avec le support (Odaiji ne pourra pas joindre JuxtaLink)." -ForegroundColor Yellow }
}

# ---------------------------------------------------------------- 2. MSI
if (-not $NoInstall) {
    Say "2/6  Installation de JuxtaLink (MSI silencieux)"
    $msi = Get-ChildItem "$Kit\installeurs\SetupJuxtaLink*.msi" -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $msi) { KO "installeurs\SetupJuxtaLink*.msi introuvable"; Read-Host "Entree pour fermer"; exit 1 }
    Get-Process JuxtaLink -ErrorAction SilentlyContinue | Stop-Process -Force; Start-Sleep 2
    $p = Start-Process msiexec.exe -ArgumentList "/i `"$($msi.FullName)`" /qn /norestart ALLUSERS=1" -Wait -PassThru
    if ($p.ExitCode -in 0,3010,1638) { OK "JuxtaLink installe (msiexec $($p.ExitCode))" } else { KO "msiexec code $($p.ExitCode)"; Read-Host "Entree pour fermer"; exit 1 }
} else { Say "2/6  Installation sautee (-NoInstall)" }

# ---------------------------------------------------------------- 3. user.config
Say "3/6  user.config (serveurs MadeForMed)"
$ucDir = Join-Path $UserAppData "juxta\juxtalink"; New-Item -ItemType Directory -Force $ucDir | Out-Null
$uc = Join-Path $ucDir "user.config"
if (Test-Path "$Kit\user.config") {
    if (Test-Path $uc) { Copy-Item $uc "$uc.bak-$(Get-Date -Format yyyyMMdd-HHmm)" -Force }
    Copy-Item "$Kit\user.config" $uc -Force; OK "user.config ecrit : $uc"
    Select-String $uc -Pattern 'tokenServerUrl|updateServerUrl|"port"' | ForEach-Object { Write-Host "    $($_.Line.Trim())" }
} else { KO "user.config absent du kit" }

# ---------------------------------------------------------------- 4. FIX AUTO
Say "4/6  Corrections automatiques sures (sesam.ini, galss.ini, MICA x64 jFSE) - une fenetre s'ouvre, la laisser finir"
Write-Host "    (cartes CPS + Vitale inserees pour que galss.ini soit verifie avec les bons lecteurs)"
Run-Diag ($diagArgs + @("-Prefix","Fix","-Auto"))
$fix = Get-ChildItem "$Desktop\Fix_*.txt" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($fix) { Get-Content $fix.FullName | Select-String '^>>|7[a-e]\.|\[OK\]   (sesam|galss|MICA)' | ForEach-Object { Write-Host "    $($_.Line.Trim())" }; Remove-Item $fix.FullName -Force }
if ($WithAutofix) {
    $dst = "C:\ProgramData\MadeForMed"; New-Item -ItemType Directory -Force $dst | Out-Null
    Copy-Item "$Kit\galss-autofix.ps1" $dst -Force; Copy-Item "$Kit\Reparer-lecteur.bat" $Desktop -Force
    $cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$dst\galss-autofix.ps1`""
    schtasks /create /tn "MadeForMed galss-autofix (session)" /tr "$cmd" /sc onlogon /rl highest /f | Out-Null
    schtasks /create /tn "MadeForMed galss-autofix (5min)"    /tr "$cmd" /sc minute /mo 5 /rl highest /f | Out-Null
    OK "galss-autofix installe (taches planifiees + icone Reparer-lecteur.bat sur le Bureau)"
}

# ---------------------------------------------------------------- 4b. NAVIGATEURS
Say "4b/6  Chrome / Edge : autoriser Odaiji a joindre JuxtaLink (Local Network Access)"
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$Kit\Autoriser-Odaiji-Chrome.ps1" 2>&1 | Where-Object { $_ -notmatch 'Entree pour fermer' } | ForEach-Object { Write-Host "    $_" }

# ---------------------------------------------------------------- 5. LANCER
Say "5/6  Lancement de JuxtaLink"
$exe = "C:\Program Files (x86)\Juxta\JuxtaLink\JuxtaLink.exe"
if (Test-Path $exe) { Start-JuxtaUser $exe; Start-Sleep 8; if (Get-Process JuxtaLink -ErrorAction SilentlyContinue) { OK "JuxtaLink en cours d'execution" } else { KO "JuxtaLink ne s'est pas lance" } } else { KO "JuxtaLink.exe introuvable" }
Write-Host "    >>> Dans Odaiji, faire maintenant UNE lecture CPS + Vitale : le plugin SSV et ses prerequis" -ForegroundColor Magenta
Write-Host "    >>> (FSV, GALSS, MICA, Cryptolib) se telechargent et s'installent. Accepter les fenetres UAC." -ForegroundColor Magenta
Read-Host "    Entree une fois la lecture tentee (ou tout de suite pour passer)"

# ---------------------------------------------------------------- 5a. CORRECTIONS APRES INSTALLATION DU PLUGIN
Say "5a/6  Corrections apres installation des composants par le plugin (sesam.ini, tables, MICA)"
Run-Diag ($diagArgs + @("-Prefix","Fix2","-Auto"))
$fix2 = Get-ChildItem "$Desktop\Fix2_*.txt" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($fix2) { Get-Content $fix2.FullName | Select-String '^>>|7[a-e]\.|\[OK\]   (sesam|galss|MICA|mica)' | ForEach-Object { Write-Host "    $($_.Line.Trim())" }; Remove-Item $fix2.FullName -Force }

# ---------------------------------------------------------------- 5b. SANS GALSS (par defaut, demande Juxta)
if (-not $AvecGalss) {
    Say "5b/6  Full PC/SC (demande Juxta) : retrait du GALSS x86 Juxta + blocage de sa reinstallation"
    Run-Diag ($diagArgs + @("-Prefix","Galss","-Auto","-SansGalss"))
    $gl = Get-ChildItem "$Desktop\Galss_*.txt" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($gl) { Get-Content $gl.FullName | Select-String '7g\.|Prerequis|BLOQUER|GALSS x86|msiexec|Residus' | ForEach-Object { Write-Host "    $($_.Line.Trim())" }; Remove-Item $gl.FullName -Force }
    Write-Host "    >>> Refaire une lecture CPS + Vitale et une ADRi dans Odaiji (mode PC/SC direct)." -ForegroundColor Magenta
    Read-Host "    Entree une fois testee"
}

# ---------------------------------------------------------------- 5c. REDEMARRAGE PROPRE
# Retour terrain DRSAMITIER 24/09 : 1re lecture Vitale en echec, OK apres redemarrage de JuxtaLink
# (composants installes par le plugin pendant la session JuxtaLink). On termine toujours par un redemarrage.
Say "5c/6  Redemarrage propre de JuxtaLink (charge les composants installes par le plugin)"
Get-Process JuxtaLink -ErrorAction SilentlyContinue | Stop-Process -Force; Start-Sleep 3
if (Test-Path $exe) { Start-JuxtaUser $exe; Start-Sleep 10; if (Get-Process JuxtaLink -ErrorAction SilentlyContinue) { OK "JuxtaLink redemarre" } else { KO "JuxtaLink ne s'est pas relance : le lancer depuis le menu Demarrer" } }
Write-Host "    >>> Lecture de CONTROLE dans Odaiji : CPS + Vitale (les deux cartes inserees)." -ForegroundColor Magenta
Read-Host "    Entree une fois la lecture faite"

# ---------------------------------------------------------------- 6. APRES
Say "6/6  Diagnostic APRES"
Run-Diag ($diagArgs + @("-Prefix","Apres"))
$apres = Get-ChildItem "$Desktop\Apres_*.txt" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($apres) { OK "Rapport : $($apres.FullName)"; Get-Content $apres.FullName | Select-String 'Scenario :|^\s*\[KO\]|^\s*\[WARN\]' | Select-Object -First 12 | ForEach-Object { Write-Host "    $($_.Line.Trim())" } }
Write-Host "`nTermine. Si le scenario n'est pas OK : envoyer Avant_*.txt et Apres_*.txt dans le channel Claude."
Read-Host "Entree pour fermer"
