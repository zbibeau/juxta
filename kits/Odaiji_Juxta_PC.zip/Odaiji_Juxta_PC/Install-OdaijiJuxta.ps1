<#
=====================================================================
 Odaiji_Juxta - Installation propre de JuxtaLink sur Windows
 MadeForMed / Odaiji - v0.3.2 (24/09/2026)
=====================================================================
 Lance par Installer-Odaiji-Juxta.bat (elevation UAC automatique).
 Contenu attendu du dossier :
   installeurs\SetupJuxtaLinkx86.msi   installeur JuxtaLink (WiX, 2.2.3 x86)
   installeurs\fsv-*.msi               FSV du GIE (repli si sesam.ini/tables manquent)
   user.config                          configuration MadeForMed
   OdaijiJuxta.ps1                      diagnostic / reparation
   galss-autofix.ps1 + Reparer-lecteur.bat   (option -WithAutofix)
 Deroule : 1 diag AVANT -> 2 MSI JuxtaLink -> 3 user.config -> 4 corrections auto sures -> 4b politiques Chrome/Edge
           -> 5 lancement + premiere lecture (le plugin installe FSV/GALSS/MICA/Cryptolib) -> 5a corrections rejouees
           -> 5 lancement + premiere lecture (le plugin SSV s'installe) -> 6 diag APRES
 Options : -NoInstall (poste deja equipe) ; -WithAutofix (lecteur a nommage instable)
           -AvecGalss (ne PAS retirer le GALSS x86 Juxta ; par defaut il est retire et bloque apres
                       la premiere lecture, avec retour arriere automatique si la lecture echoue ensuite)
 Le plugin SSV et ses prerequis (FSV, GALSS, MICA, Cryptolib) sont telecharges par
 JuxtaLink a la PREMIERE REQUETE : Internet requis, et un admin present pour l'UAC.
=====================================================================
#>
param([switch]$NoInstall, [switch]$WithAutofix, [switch]$AvecGalss)
trap { Write-Host ("`nERREUR : " + $_.Exception.Message) -ForegroundColor Red; Write-Host ($_.InvocationInfo.PositionMessage) -ForegroundColor DarkGray; Read-Host "Envoyer cette capture dans le channel Claude. Entree pour fermer"; exit 1 }

$Kit = Split-Path -Parent $MyInvocation.MyCommand.Path
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { $a=@("-NoProfile","-ExecutionPolicy","Bypass","-File","`"$PSCommandPath`""); if ($NoInstall){$a+="-NoInstall"}; if ($WithAutofix){$a+="-WithAutofix"}; if ($AvecGalss){$a+="-AvecGalss"}; Start-Process powershell.exe -Verb RunAs -ArgumentList $a; exit }
# Start-Process -Wait attend aussi les processus ENFANTS : si le diag relance JuxtaLink, l'installeur restait bloque
# (etape 4, DRSAMITIER 24/09). WaitForExit() n'attend que le diag lui-meme.
function Run-Diag { param($ArgList) $p = Start-Process powershell.exe -ArgumentList $ArgList -PassThru; $p.WaitForExit() }
function Say { param($t) Write-Host "`n==> $t" -ForegroundColor Cyan }
function OK  { param($t) Write-Host "    [OK]  $t" -ForegroundColor Green }
function KO  { param($t) Write-Host "    [KO]  $t" -ForegroundColor Red }

# --- Profil de l'utilisateur connecte (le medecin), meme si l'UAC a utilise un autre compte
$owner = (Get-CimInstance Win32_Process -Filter "name='explorer.exe'" | Select-Object -First 1 | Invoke-CimMethod -MethodName GetOwner)
$prof = (Get-CimInstance Win32_UserProfile | Where-Object { $_.LocalPath -like ("*\" + $owner.User) } | Select-Object -First 1).LocalPath
if (-not $prof) { $prof = $env:USERPROFILE }
$UserAppData = Join-Path $prof "AppData\Roaming"
$Desktop = Join-Path $prof "Desktop"
Write-Host "Odaiji_Juxta - installation JuxtaLink sur $env:COMPUTERNAME pour l'utilisateur $($owner.User)"
$diagArgs = @("-NoProfile","-ExecutionPolicy","Bypass","-File","`"$Kit\OdaijiJuxta.ps1`"","-NoPause","-UserAppData","`"$UserAppData`"")

# ---------------------------------------------------------------- 1. AVANT
Say "1/6  Diagnostic AVANT (lecture seule)"
Run-Diag ($diagArgs + @("-Prefix","Avant"))
$avant = Get-ChildItem "$Desktop\Avant_*.txt" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($avant) { OK "Rapport : $($avant.FullName)"; Get-Content $avant.FullName | Select-String '^\s*\[KO\]|Scenario :' | Select-Object -First 10 | ForEach-Object { Write-Host "    $($_.Line.Trim())" } }

# ---------------------------------------------------------------- 2. MSI
if (-not $NoInstall) {
    Say "2/6  Installation de JuxtaLink (MSI silencieux)"
    $msi = Get-ChildItem "$Kit\installeurs\SetupJuxtaLink*.msi" -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $msi) { KO "installeurs\SetupJuxtaLink*.msi introuvable"; Read-Host "Entree pour fermer"; exit 1 }
    Get-Process JuxtaLink -ErrorAction SilentlyContinue | Stop-Process -Force; Start-Sleep 2
    $p = Start-Process msiexec.exe -ArgumentList "/i `"$($msi.FullName)`" /qn /norestart ALLUSERS=1" -Wait -PassThru
    if ($p.ExitCode -in 0,3010,1638) { OK "JuxtaLink installe (msiexec $($p.ExitCode))" } else { KO "msiexec code $($p.ExitCode)"; Read-Host "Entree pour fermer"; exit 1 }
} else { Say "2/6  Installation sautee (-NoInstall)" }

# ---------------------------------------------------------------- 3. user.config
Say "3/6  user.config (serveurs MadeForMed)"
$ucDir = Join-Path $UserAppData "juxta\juxtalink"; New-Item -ItemType Directory -Force $ucDir | Out-Null
$uc = Join-Path $ucDir "user.config"
if (Test-Path "$Kit\user.config") {
    if (Test-Path $uc) { Copy-Item $uc "$uc.bak-$(Get-Date -Format yyyyMMdd-HHmm)" -Force }
    Copy-Item "$Kit\user.config" $uc -Force; OK "user.config ecrit : $uc"
    Select-String $uc -Pattern 'tokenServerUrl|updateServerUrl|"port"' | ForEach-Object { Write-Host "    $($_.Line.Trim())" }
} else { KO "user.config absent du kit" }

# ---------------------------------------------------------------- 4. FIX AUTO
Say "4/6  Corrections automatiques sures (sesam.ini, galss.ini, MICA x64 jFSE) - une fenetre s'ouvre, la laisser finir"
Write-Host "    (cartes CPS + Vitale inserees pour que galss.ini soit verifie avec les bons lecteurs)"
Run-Diag ($diagArgs + @("-Prefix","Fix","-Auto"))
$fix = Get-ChildItem "$Desktop\Fix_*.txt" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($fix) { Get-Content $fix.FullName | Select-String '^>>|7[a-e]\.|\[OK\]   (sesam|galss|MICA)' | ForEach-Object { Write-Host "    $($_.Line.Trim())" }; Remove-Item $fix.FullName -Force }
if ($WithAutofix) {
    $dst = "C:\ProgramData\MadeForMed"; New-Item -ItemType Directory -Force $dst | Out-Null
    Copy-Item "$Kit\galss-autofix.ps1" $dst -Force; Copy-Item "$Kit\Reparer-lecteur.bat" $Desktop -Force
    $cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$dst\galss-autofix.ps1`""
    schtasks /create /tn "MadeForMed galss-autofix (session)" /tr "$cmd" /sc onlogon /rl highest /f | Out-Null
    schtasks /create /tn "MadeForMed galss-autofix (5min)"    /tr "$cmd" /sc minute /mo 5 /rl highest /f | Out-Null
    OK "galss-autofix installe (taches planifiees + icone Reparer-lecteur.bat sur le Bureau)"
}

# ---------------------------------------------------------------- 4b. NAVIGATEURS
Say "4b/6  Chrome / Edge : autoriser Odaiji a joindre JuxtaLink (Local Network Access)"
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$Kit\Autoriser-Odaiji-Chrome.ps1" 2>&1 | Where-Object { $_ -notmatch 'Entree pour fermer' } | ForEach-Object { Write-Host "    $_" }

# ---------------------------------------------------------------- 5. LANCER
Say "5/6  Lancement de JuxtaLink"
$exe = "C:\Program Files (x86)\Juxta\JuxtaLink\JuxtaLink.exe"
if (Test-Path $exe) { Start-Process $exe; Start-Sleep 6; if (Get-Process JuxtaLink -ErrorAction SilentlyContinue) { OK "JuxtaLink en cours d'execution" } else { KO "JuxtaLink ne s'est pas lance" } } else { KO "JuxtaLink.exe introuvable" }
Write-Host "    >>> Dans Odaiji, faire maintenant UNE lecture CPS + Vitale : le plugin SSV et ses prerequis" -ForegroundColor Magenta
Write-Host "    >>> (FSV, GALSS, MICA, Cryptolib) se telechargent et s'installent. Accepter les fenetres UAC." -ForegroundColor Magenta
Read-Host "    Entree une fois la lecture tentee (ou tout de suite pour passer)"

# ---------------------------------------------------------------- 5a. CORRECTIONS APRES INSTALLATION DU PLUGIN
Say "5a/6  Corrections apres installation des composants par le plugin (sesam.ini, tables, MICA)"
Run-Diag ($diagArgs + @("-Prefix","Fix2","-Auto"))
$fix2 = Get-ChildItem "$Desktop\Fix2_*.txt" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($fix2) { Get-Content $fix2.FullName | Select-String '^>>|7[a-e]\.|\[OK\]   (sesam|galss|MICA|mica)' | ForEach-Object { Write-Host "    $($_.Line.Trim())" }; Remove-Item $fix2.FullName -Force }

# ---------------------------------------------------------------- 5b. SANS GALSS (par defaut, demande Juxta)
if (-not $AvecGalss) {
    Say "5b/6  Full PC/SC (demande Juxta) : retrait du GALSS x86 Juxta + blocage de sa reinstallation"
    Run-Diag ($diagArgs + @("-Prefix","Galss","-Auto","-SansGalss"))
    $gl = Get-ChildItem "$Desktop\Galss_*.txt" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($gl) { Get-Content $gl.FullName | Select-String '7g\.|Prerequis|BLOQUER|GALSS x86|msiexec|Residus' | ForEach-Object { Write-Host "    $($_.Line.Trim())" }; Remove-Item $gl.FullName -Force }
    Write-Host "    >>> Refaire une lecture CPS + Vitale et une ADRi dans Odaiji (mode PC/SC direct)." -ForegroundColor Magenta
    Read-Host "    Entree une fois testee"
}

# ---------------------------------------------------------------- 6. APRES
Say "6/6  Diagnostic APRES"
Run-Diag ($diagArgs + @("-Prefix","Apres"))
$apres = Get-ChildItem "$Desktop\Apres_*.txt" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($apres) { OK "Rapport : $($apres.FullName)"; Get-Content $apres.FullName | Select-String 'Scenario :|^\s*\[KO\]|^\s*\[WARN\]' | Select-Object -First 12 | ForEach-Object { Write-Host "    $($_.Line.Trim())" } }
Write-Host "`nTermine. Si le scenario n'est pas OK : envoyer Avant_*.txt et Apres_*.txt dans le channel Claude."
Read-Host "Entree pour fermer"
